using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace ShackCommunityJSON
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        int width = 720;
        int height = 1280;

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Shack shack;
        Page page;
        Texture2D circle;
        Texture2D pixel;
        internal Dictionary<string, Shacker> shackers;
        Vector2 avgPosition;
        SpriteFont font;
        SpriteFont smallfont;
        Camera2d camera;
        Vector2 cameraShift;
        int lastScrollWheelValue = 0;
        MouseState lastMouseState;
        KeyboardState lastKeyboardState;
        Post draggedPost;
        Post selectedPost;
        Post highlightedPost;
        String status;
        Vector2 mouseLocation;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferHeight = width;
            graphics.PreferredBackBufferWidth = height;
            camera = new Camera2d(graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight);
            Content.RootDirectory = "Content";
            Shacker.rand = new Random();
            Post.rand = new Random();
            shackers = new Dictionary<string, Shacker>();
            shack = new Shack(shackers);
            IsMouseVisible = true;
            status = "";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            page = shack.getPage(1);
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            circle = Content.Load<Texture2D>("circle");
            Post.width = circle.Width;
            Post.height = circle.Height;
            pixel = Content.Load<Texture2D>("pixel");
            font = Content.Load<SpriteFont>("font");
            smallfont = Content.Load<SpriteFont>("smallfont");
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            handleInput(gameTime);

            if (page != null)
                updateThreads();

            base.Update(gameTime);
        }

        private void handleInput(GameTime gameTime) {
            MouseState mouse = Mouse.GetState();
            KeyboardState kb = Keyboard.GetState();
            if (mouse.ScrollWheelValue > lastScrollWheelValue || (kb.IsKeyDown(Keys.Up) && lastKeyboardState.IsKeyUp(Keys.Up)))
                camera.Zoom *= 0.8f;
            else if (mouse.ScrollWheelValue < lastScrollWheelValue || (kb.IsKeyDown(Keys.Down) && lastKeyboardState.IsKeyUp(Keys.Down)))
                camera.Zoom *= 1.3f;
            lastScrollWheelValue = mouse.ScrollWheelValue;

            mouseLocation = getWorldCoords(mouse.X, mouse.Y);

            Post post = postAt(mouse.X, mouse.Y);
            if (mouse.RightButton == ButtonState.Pressed && draggedPost == null)
            {
                if (post != null)
                {
                    draggedPost = post;
                    draggedPost.position = mouseLocation;
                    selectedPost = null;
                }
                else
                {
                    cameraShift = cameraShift + getWorldCoords(lastMouseState.X, lastMouseState.Y) - mouseLocation;
                }
            }
            else if (mouse.RightButton == ButtonState.Pressed && draggedPost != null)
            {
                draggedPost.position = mouseLocation;
            }
            else if (mouse.LeftButton == ButtonState.Pressed)
            {
                if (post != null)
                {
                    selectedPost = post;
                }
                else if (lastMouseState.LeftButton == ButtonState.Released)
                {
                    selectedPost = null;
                }
            }
            else if (mouse.RightButton == ButtonState.Released && draggedPost != null)
            {
                draggedPost = null;
                selectedPost = null;
            }
            lastKeyboardState = kb;
            lastMouseState = mouse;
            highlightedPost = post;
        }

        /// <summary>
        /// Finds the shacker at a given coordinates
        /// </summary>
        /// <param name="x">x coordinate of desired location</param>
        /// <param name="y">x coordinate of desired location</param>
        /// <returns>Returns shacker at coordinate, or null if none found</returns>
        private Post postAt(int x, int y)
        {
            Vector2 point = getWorldCoords(x, y);
            foreach (Post post in page)
            {
                if (Vector2.Distance(point, post.position) < post.radius)
                    return post;
            }
            if (selectedPost != null && selectedPost is RootPost)
            {
                foreach (Post reply in ((RootPost)selectedPost).replies)
                    if (Vector2.Distance(point, reply.position) < reply.radius)
                        return reply;
            }
            return null;
        }

        /// <summary>
        /// Given a mouse state, returns a vector of the mouse coordinates in world coordinates
        /// </summary>
        /// <param name="mouse">Current mouse state</param>
        /// <returns>Mouse coordinates in world coordinates</returns>
        private Vector2 getWorldCoords(int x, int y)
        {
            Matrix inverseWorldMatrix = Matrix.Invert(camera.get_transformation());
            Vector2 mousePosition = new Vector2(x, y);
            return Vector2.Transform(mousePosition, inverseWorldMatrix);
        }

        private void updateThreads()
        {
            lock (page)
            {
                avgPosition = Vector2.Zero;
                foreach (RootPost rootpost in page)
                {
                    if (rootpost == draggedPost) break;
                    Vector2 netForce = Vector2.Zero;
                    foreach (RootPost other in page)
                    {
                        if (other != rootpost)
                        {
                            float rsq = Vector2.DistanceSquared(rootpost.position, other.position);
                            netForce += 2000 * (rootpost.position - other.position) / rsq; // repulsion
                            if (rootpost == selectedPost)
                                if (rootpost.category.Equals(other.category))
                                    netForce += 0.006f * (other.position - rootpost.position); // attraction between related 
                                else
                                    netForce += 0.005f * (other.position - rootpost.position); // attraction between unrelated
                            else
                                if (rootpost.category.Equals(other.category))
                                    netForce += 0.005f * (other.position - rootpost.position); // attraction between related 
                                else
                                    netForce += 0.004f * (other.position - rootpost.position); // attraction between unrelated
                        }
                    }
                    rootpost.velocity = (rootpost.velocity + netForce) * 0.85f;
                    rootpost.position += rootpost.velocity;
                    avgPosition += rootpost.position;

                    if (rootpost == selectedPost && rootpost.replies.Count > 0)
                        updateReplies(rootpost.replies, rootpost);
                }
                avgPosition /= page.Count;
                camera.Pos = avgPosition + cameraShift;
            }
        }

        /// <summary>
        /// Updates position of a given thread and its replies, recursively
        /// </summary>
        /// <param name="replies"></param>
        /// <param name="post"></param>
        private void updateReplies(List<Post> replies, Post post)
        {
            float rsq = Vector2.DistanceSquared(post.position, replies[0].position);
            Vector2 netForce = 0.06f * (post.position - replies[0].position); // attraction to root post
            replies[0].velocity = (replies[0].velocity + netForce) * 0.8f;
            replies[0].position += replies[0].velocity;
            for (int i = 0; i < replies.Count; i++)
            {
                netForce = Vector2.Zero;

                for (int j = 0; j < replies.Count; j++)
                {
                    if (i != j)
                    {
                        rsq = Vector2.DistanceSquared(replies[j].position, replies[i].position);
                        netForce += 40 * (replies[i].position - replies[j].position) / rsq; // repulsion
                        if (replies[j] == replies[i].parent)
                            netForce += 0.01f * (replies[j].position - replies[i].position); // attraction
                    }
                    if (Vector2.Distance(mouseLocation, replies[i].position) < replies[i].radius)
                        netForce += 0.02f * (mouseLocation - replies[i].position);
                }
                if (replies[i] != draggedPost)
                {
                    replies[i].velocity = (replies[i].velocity + netForce) * 0.8f;
                    replies[i].position += replies[i].velocity;
                }
            }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, null, null, null, null, camera.get_transformation());
            foreach (RootPost thread in page)
            {
                Color colour = thread.colour;
                if (selectedPost != null && selectedPost != thread)
                    colour = colour * 0.25f;
                spriteBatch.Draw(circle, thread.position, null, colour, 0.0f, thread.origin, thread.size, SpriteEffects.None, 1.0f);
                if (thread == selectedPost)
                    drawPosts(spriteBatch, thread);
                if (highlightedPost != null)
                {
                    spriteBatch.Draw(pixel, new Rectangle((int)highlightedPost.position.X + 20, (int)highlightedPost.position.Y + 20, (int)smallfont.MeasureString(highlightedPost.preview).X, 50), new Color(32, 34, 36));
                    spriteBatch.DrawString(smallfont, highlightedPost.author.name, highlightedPost.position + new Vector2(20, 20), new Color(243, 231, 181));
                    spriteBatch.DrawString(smallfont, highlightedPost.preview, highlightedPost.position + new Vector2(20, 50), Color.White);
                }
            }
            spriteBatch.End();

            spriteBatch.Begin();
            spriteBatch.DrawString(font, status, new Vector2(20, 65), Color.White);
            spriteBatch.DrawString(font, "Ontopic", new Vector2(20, 85), Color.White);
            spriteBatch.DrawString(font, "Offtopic", new Vector2(20, 105), Color.DarkSlateGray);
            spriteBatch.DrawString(font, "NWS", new Vector2(20, 125), Color.Red);
            spriteBatch.DrawString(font, "Stupid", new Vector2(20, 145), Color.Blue);
            spriteBatch.DrawString(font, "Reply", new Vector2(20, 185), Color.Green);
            spriteBatch.DrawString(font, "Moderator", new Vector2(20, 205), Color.GreenYellow);
            spriteBatch.DrawString(font, "Original poster", new Vector2(20, 225), Color.Yellow);
            spriteBatch.End();

            base.Draw(gameTime);
        }

        /// <summary>
        /// Recursive function that draws posts
        /// </summary>
        /// <param name="posts">List of posts</param>
        private void drawPosts(SpriteBatch sb, RootPost root)
        {
            lock (root.replies)
            {
                for (int i = 0; i < root.replies.Count; i++)
                {
                    drawLine(sb, pixel, 2, Color.Gray, root.replies[i].parent.position, root.replies[i].position);
                    Color colour = root.replies[i].colour;
                    if (root.replies[i].author == root.author)
                        colour = Color.Yellow;
                    sb.Draw(circle, root.replies[i].position, null, colour, 0.0f, root.replies[i].origin, root.replies[i].size, SpriteEffects.None, 1.0f);
                }
            }
        }

        /// <summary>
        /// Renders a line between two points. From http://www.xnawiki.com/index.php?title=Drawing_2D_lines_without_using_primitives
        /// </summary>
        /// <param name="sb">Spritebatch to render to</param>
        /// <param name="tex">Texture of line to use (usually just a blank square) </param>
        /// <param name="width">Line thickness</param>
        /// <param name="colour">Colour of line</param>
        /// <param name="p1">Start point of line</param>
        /// <param name="p2">End point of line</param>
        private void drawLine(SpriteBatch sb, Texture2D tex, float width, Color colour, Vector2 p1, Vector2 p2)
        {
            float angle = (float)Math.Atan2(p2.Y - p1.Y, p2.X - p1.X);
            float length = Vector2.Distance(p1, p2);

            sb.Draw(tex, p1, null, colour,
                       angle, Vector2.Zero, new Vector2(length, width),
                       SpriteEffects.None, 0);
        }
    }
}

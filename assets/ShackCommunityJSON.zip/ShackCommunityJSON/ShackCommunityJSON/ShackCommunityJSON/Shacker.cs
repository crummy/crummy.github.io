﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace ShackCommunityJSON
{
    class Shacker
    {
        public string name;
        public RootPost lastThread;
        public int lastThreadPosts;
        public static Random rand;

        public static List<String> moderators = new List<String>{
            "Ajax",
            "brickmatt",
            "busdriver3030",
            "Carnivac",
            "Cygnus X-1",
            "Dante",
            "Dave-A",
            "Degenerate",
            "dognose",
            "drucifer",
            "edgewise",
            "edlin",
            "filtersweep",
            "geedeck",
            "genjuro",
            "haiku",
            "helvetica",
            "hirez",
            "Kaiser",
            "king_darius",
            "lacker",
            "mikecyb",
            "multisync",
            "ninjase",
            "Paranoid Android",
            "Portax",
            "pupismyname",
            "Raoul Duke",
            "redfive",
            "Sexpansion Pack",
            "sgtsanity",
            "thekidd",
            "tomservo",
            "UtilityMaximizer",
            "zakk"
        };

        public bool isModerator
        {
            get
            {
                if (moderators.Contains(name)) return true;
                else return false;
            }
        }

        public Shacker(string name, RootPost thread, int posts)
        {
            this.name = name;
            lastThread = thread;
            lastThreadPosts = posts;
        }

        public Shacker(string name)
        {
            this.name = name;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShackCommunityJSON
{
    class Page : List<RootPost>
    {
        public int page;
        public int story_id;
        public string story_name;
        //public Dictionary<string, Shacker> shackers;
    }
}

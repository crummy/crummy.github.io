﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace ShackCommunityJSON
{
    class RootPost : Post
    {
        public Dictionary<string, int> participants;
        public List<Post> replies;
        //public List<int> replyids;
        public bool repliesLoaded;

        public override float size
        {
            get
            {
                if (repliesLoaded)
                    return (float)Math.Sqrt(reply_count * 0.001f);
                else
                    return 0.01f;
            }
        }

        public override Color colour
        {
            get
            {
                switch (category)
                {
                    case "ontopic":
                        return Color.White;
                    case "offtopic":
                        return Color.DarkSlateGray;
                    case "nws":
                        return Color.Red;
                    case "stupid":
                        return Color.Blue;
                    default:
                        return Color.DarkSlateGray;
                }
            }
        }

        public RootPost(int id)
        {
            this.id = id;
            participants = new Dictionary<string, int>();
            velocity = Vector2.Zero;
            position = new Vector2(rand.Next(width), rand.Next(height));
            replies = new List<Post>();
            repliesLoaded = false;
        }
    }
}

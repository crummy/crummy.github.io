﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace ShackCommunityJSON
{
    class Post
    {
        public Shacker author;
        public string body;
        public string category;
        //public string date;
        public int id;
        public int last_reply_id;
        public string preview;
        public int reply_count;
        public Post parent;
        public Vector2 position;
        public Vector2 velocity;

        public static int width;
        public static int height;
        public static Random rand;

        public Post()
        {
            position = new Vector2(rand.Next(width*10), rand.Next(height*10));
            velocity = Vector2.Zero;
        }

        public virtual float size
        {
            get { return 0.05f; }
        }

        public Vector2 origin
        {
            get { return new Vector2(width / 2, height / 2); }
        }

        public float radius
        {
            get { return width * size * 0.5f; }
        }

        public virtual Color colour
        {
            get
            {
                if (author.isModerator)
                    return Color.GreenYellow;
                else
                    return Color.Green;
            }
        }
    }
}

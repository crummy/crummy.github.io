﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using FridayThe13th;
using System.Threading;

namespace ShackCommunityJSON
{
    /// <summary>
    /// Acts as shack API.
    /// Documentation at http://shackapi.stonedonkey.com/readme/
    /// </summary>
    class Shack
    {
        public Dictionary<string, Shacker> shackers;
        private string baseURL = "http://shackapi.stonedonkey.com/";
        private Page page;

        public Shack(Dictionary<string, Shacker> shackers)
        {
            this.shackers = shackers;
            page = new Page();
        }

        public dynamic getJsonForUrl(string url)
        {
            StringBuilder sb = new StringBuilder();
            byte[] buf = new byte[8192];
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream resStream = response.GetResponseStream();
            int count = 0;
            do
            {
                count = resStream.Read(buf, 0, buf.Length);
                if (count != 0)
                    sb.Append(Encoding.ASCII.GetString(buf, 0, count));
            } while (count > 0);
            var jsp = new JsonParser() { };
            return jsp.Parse(sb.ToString());
        }

        /// <summary>
        /// Returns a given page
        /// </summary>
        /// <param name="pagenum">Page number</param>
        /// <returns>Page with story name, ID, and top level posts with participants</returns>
        public Page getPage(int pagenum)
        {
            Thread thread = new Thread(_getPage);
            thread.Start();
            return page;
        }

        private void _getPage()
        {
            lock (page)
            {
                dynamic json = getJsonForUrl(baseURL + "index.json");

                page.page = int.Parse(json["page"]);
                page.story_name = json["story_name"];
                page.story_id = int.Parse(json["story_id"]);

                List<dynamic> Comments = json["comments"];
                page.Clear();
                foreach (dynamic comment in Comments)
                {
                    RootPost post = new RootPost(int.Parse(comment["id"]));
                    post.author = addShacker(comment["author"]);
                    post.reply_count = int.Parse(comment["reply_count"]);
                    post.last_reply_id = int.Parse(comment["last_reply_id"]);
                    post.preview = comment["preview"];
                    post.category = comment["category"];
                    foreach (dynamic shacker in comment["participants"])
                        post.participants.Add(shacker["username"], (int)shacker["post_count"]);
                    page.Add(post);

                    if (post.reply_count > 0)
                    {
                        Thread thread = new Thread(() => populatePost(post.replies, post, post.id));
                        thread.Start();
                    }
                }
            }
        }

        /// <summary>
        /// Adds a shacker if none exists; else returns the existing shacker of that name
        /// </summary>
        /// <param name="name">Name to of shacker</param>
        /// <returns>New shacker or existing shacker if possible</returns>
        private Shacker addShacker(string name)
        {
            if (shackers.ContainsKey(name))
                return shackers[name];
            else {
                Shacker newShacker = new Shacker(name);
                shackers[name] = newShacker;
                return newShacker;
            }
        }

        private void populatePost(List<Post> posts, RootPost root, int id)
        {
            dynamic json = getJsonForUrl(baseURL + "thread/" + id + ".json");
            _populatePost(posts, root, json);
            root.repliesLoaded = true;
        }

        private void _populatePost(List<Post> posts, Post root, dynamic json)
        {
            foreach (dynamic comment in json["comments"])
            {
                Post post = new Post();
                post.id = int.Parse(comment["id"]);
                post.body = comment["body"];
                post.preview = comment["preview"];
                post.author = addShacker(comment["author"]);
                post.preview = comment["preview"];
                post.category = comment["category"];
                post.reply_count = int.Parse(comment["reply_count"]);
                post.parent = root;
                posts.Add(post);
                if (comment["comments"] != null)
                {
                    //post.last_reply_id = int.Parse(comment["last_reply_id"]);
                    _populatePost(posts, post, comment);
                }

            }
        }

        public Post getPost(int id)
        {
            dynamic json = getJsonForUrl(baseURL + "thread/" + id + ".json");
            Post post = new Post();
            dynamic data = json["comments"]["comments"];
            post.preview = data["preview"];
            return post;
        }
    }
}

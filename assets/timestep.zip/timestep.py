# A Python implementation of Glenn Fiedler's accurate timestep algorithm
# Code adapted mostly line for line from his code here:
# http://gafferongames.com/game-physics/fix-your-timestep/
# Comments are my own.
# - Malcolm Crum, www.malcolmcrum.com

import pygame
from pygame.locals import *
pygame.init()

width = 640
height = 480
current = {"x": 100, "v": 1}
previous = current
t = 0.0
dt = 0.1
currentTime = 0.0
accumulator = 0.0

window = pygame.display.set_mode((width, height))
pygame.display.set_caption("Timestep")
surface = pygame.display.get_surface()

def didUserQuit (events):
    for event in events:
        if event.type == QUIT:
            return True
        else:
            return False

def interpolate(previous, current, alpha):
    state = {}
    state["x"] = current["x"]*alpha + previous["x"]*(1-alpha)
    state["v"] = current["v"]*alpha + previous["v"]*(1-alpha)
    return state

# This just swings our value back and forth, with a bit of a slowing
# motion. In a real game more interesting stuff would happen here.
def acceleration(state, t):
    k = 10.0
    b = 1.0
    return -k*state["x"] - b*state["v"]

# The two evaluate functions basically perform Euler integration
# with a point and time.
def evaluate(initial, t):
    output = {}
    output["dx"] = initial["v"]
    output["dv"] = acceleration(initial, t)
    return output

def evaluate2(initial, t, dt, d):
    state = {}
    state["x"] = initial["x"] + d["dx"]*dt
    state["v"] = initial["v"] + d["dv"]*dt
    output = {}
    output["dx"] = state["v"]
    output["dv"] = acceleration(state, t+dt)
    return output

# This is Runge Kutta 4th order in action. See
# http://en.wikipedia.org/wiki/RK4 for further description.
def integrate(state, t, dt):
    a = evaluate(state, t)
    b = evaluate2(state, t, dt*0.5, a)
    c = evaluate2(state, t, dt*0.5, b)
    d = evaluate2(state, t, dt, c)
    
    dxdt = 1./6. * (a["dx"] + 2.*(b["dx"] + c["dx"]) + d["dx"])
    dvdt = 1./6. * (a["dv"] + 2.*(b["dv"] + c["dv"]) + d["dv"])
    
    state["x"] = state["x"] + dxdt*dt
    state["v"] = state["v"] + dvdt*dt
    
while quit is not True:
    pygame.draw.rect(surface, pygame.color.Color("0x333333"), (0, 0, width, height), 0)

    inputEvents = pygame.event.get()
    quit = didUserQuit(inputEvents)
    
    newTime = pygame.time.get_ticks()
    deltaTime = (newTime - currentTime) / 1000.0
    currentTime = newTime
    
    # If deltaTime is too huge things get a little out of control, so
    # this places a cap that will only be hit if the game is running
    # very slowly.
    if (deltaTime > 0.25):
        deltaTime = 0.25
        
    accumulator = accumulator + deltaTime
    
    while (accumulator >= dt):
        accumulator = accumulator - dt
        previous = current
        integrate(current, t, dt)
        t = t + dt
        
    state = interpolate(previous, current, accumulator/dt)
    
    dot = ((width/2)+state["x"] - 2, height/2, 4, 4)
    pygame.draw.rect(surface, pygame.color.Color("white"), dot, 0)
    pygame.display.flip()
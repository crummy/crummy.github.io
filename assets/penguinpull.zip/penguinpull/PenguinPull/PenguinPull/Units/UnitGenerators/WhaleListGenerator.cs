﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    /// <summary>
    /// Self-populating LinkedList of Whales, contains a generator.
    /// </summary>
    class WhaleListGenerator : LinkedList<Whale>, IUnitList
    {
        private Generator generator; //Times and generates spawning of units

        #region Properties
        /// <summary>
        /// Determines whether Update runs.
        /// </summary>
        public bool Active { get; set; }

        /// <summary>
        /// How many milliseconds minimum before a new whale is generated.
        /// </summary>
        public int Frequency_Min
        {
            get { return generator.Frequency_Min; }
            set { generator.Frequency_Min = value; }
        }

        /// <summary>
        /// How many milliseconds maximum before a new whale is generated.
        /// </summary>
        public int Frequency_Max
        {
            get { return generator.Frequency_Max; }
            set { generator.Frequency_Max = value; }
        }

        /// <summary>
        /// The Y coordinate at which the whale's location will be set.
        /// </summary>
        public float Y_Coordinate
        {
            get { return generator.Y_Coordinate; }
            set { generator.Y_Coordinate = value; }
        }

        /// <summary>
        /// The left X coordinate bound within which the whale's location will be set.
        /// </summary>
        public float Left_Bound
        {
            get { return generator.Left_Bound; }
            set { generator.Left_Bound = value; }
        }

        /// <summary>
        /// The right X coordinate bound within which the whale's location will be set.
        /// </summary>
        public float Right_Bound
        {
            get { return generator.Right_Bound; }
            set { generator.Right_Bound = value; }
        }

        /// <summary>
        /// The minimum initial speed with which the whale will be generated.
        /// </summary>
        public Vector2 Speed_Min
        {
            get { return generator.Speed_Min; }
            set { generator.Speed_Min = value; }
        }

        /// <summary>
        /// The maximum initial speed with which the whale will be generated.
        /// </summary>
        public Vector2 Speed_Max
        {
            get { return generator.Speed_Max; }
            set { generator.Speed_Max = value; }
        }

        /// <summary>
        /// The minimum initial acceleration with which the whale will be generated.
        /// </summary>
        public Vector2 Accel_Min
        {
            get { return generator.Accel_Min; }
            set { generator.Accel_Min = value; }
        }

        /// <summary>
        /// The maximum initial acceleration with which the whale will be generated.
        /// </summary>
        public Vector2 Accel_Max
        {
            get { return generator.Accel_Max; }
            set { generator.Accel_Max = value; }
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// Creates and initializes the WhaleListGenerator.
        /// </summary>
        /// <param name="random">The RandomPlus random number generator.</param>
        /// <param name="active">Determines whether update runs.</param>
        /// <param name="frequency_min">How many milliseconds minimum before a new whale is generated.</param>
        /// <param name="frequency_max">How many milliseconds maximum before a new whale is generated.</param>
        /// <param name="y_coordinate">The Y coordinate at which the whale's location will be set.</param>
        /// <param name="left_bound">The left X coordinate bound within which the whale's location will be set.</param>
        /// <param name="right_bound">The right X coordinate bound within which the whale's location will be set.</param>
        /// <param name="speed_min">The minimum initial speed with which the whale will be generated.</param>
        /// <param name="speed_max">The maximum initial speed with which the whale will be generated.</param>
        /// <param name="accel_min">The minimum initial acceleration with which the whale will be generated.</param>
        /// <param name="accel_max">The maximum initial acceleration with which the whale will be generated.</param>
        public WhaleListGenerator(RandomPlus random, bool active, int frequency_min, int frequency_max,
            float y_coordinate, float left_bound, float right_bound,
            Vector2 speed_min, Vector2 speed_max, Vector2 accel_min, Vector2 accel_max)
        {
            Active = active;

            generator = new Generator(random, frequency_min, frequency_max,
                y_coordinate, left_bound, right_bound, speed_min, speed_max,
                accel_min, accel_max);
        }

        /// <summary>
        /// Updates the WhaleListGenerator
        /// </summary>
        /// <param name="gametime">Provides a snapshot of timing values.</param>
        public void Update(GameTime gametime)
        {
            generator.Update(gametime);
            if (generator.Generated)
                Generate();
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Recycles whales if it can. If not, creates new whales and appends to list.
        /// </summary>
        private void Generate()
        {
            Whale whale = Recycle();
            if (whale == null)
            {
                whale = new Whale();
                AddLast(whale);
            }
            whale.isAlive = true;
            whale.midPosition(new Vector2(generator.Position.X, generator.Position.Y));
            whale.velocity = new Vector2(generator.Speed.X, generator.Speed.Y);
            whale.acceleration = new Vector2(generator.Acceleration.X, generator.Acceleration.Y);
        }

        /// <summary>
        /// Searches for a whale whose isAlive == false.
        /// Returns null if all whales are alive.
        /// </summary>
        /// <returns>The found whale or null.</returns>
        private Whale Recycle()
        {
            Whale deadwhale = null;
            foreach (Whale whale in this)
            {
                if (!whale.isAlive)
                {
                    deadwhale = whale;
                    whale.msSinceStart = 0;
                    break;
                }
            }
            return deadwhale;
        }
        #endregion
    }
}

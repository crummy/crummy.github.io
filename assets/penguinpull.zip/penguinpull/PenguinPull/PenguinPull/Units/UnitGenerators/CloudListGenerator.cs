﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    /// <summary>
    /// Self-populating LinkedList of Clouds. Contains a generator.
    /// </summary>
    class CloudListGenerator : LinkedList<Cloud>, IUnitList
    {
        #region Private Fields
        internal enum CloudType {Big, Small, Snow}
        
        private Generator generator; //Times and generates spawning of units
        private RandomPlus random; //Used for choosing cloud to generate
        private CloudType nextcloud; //Next cloud to be spawned
        #endregion

        #region Properties
        /// <summary>
        /// Determines whether Update runs.
        /// </summary>
        public bool Active { get; set; }

        /// <summary>
        /// How many milliseconds minimum before a new cloud is generated.
        /// </summary>
        public int Frequency_Min
        {
            get { return generator.Frequency_Min; }
            set { generator.Frequency_Min = value; }
        }

        /// <summary>
        /// How many milliseconds maximum before a new cloud is generated.
        /// </summary>
        public int Frequency_Max
        {
            get { return generator.Frequency_Max; }
            set { generator.Frequency_Max = value; }
        }

        /// <summary>
        /// The Y coordinate at which the cloud's location will be set.
        /// </summary>
        public float Y_Coordinate
        {
            get { return generator.Y_Coordinate; }
            set { generator.Y_Coordinate = value; }
        }

        /// <summary>
        /// The left X coordinate bound within which the cloud's location will be set.
        /// </summary>
        public float Left_Bound
        {
            get { return generator.Left_Bound; }
            set { generator.Left_Bound = value; }
        }

        /// <summary>
        /// The right X coordinate bound within which the cloud's location will be set.
        /// </summary>
        public float Right_Bound
        {
            get { return generator.Right_Bound; }
            set { generator.Right_Bound = value; }
        }

        /// <summary>
        /// The minimum initial speed with which the cloud will be generated.
        /// </summary>
        public Vector2 Speed_Min
        {
            get { return generator.Speed_Min; }
            set { generator.Speed_Min = value; }
        }

        /// <summary>
        /// The maximum initial speed with which the cloud will be generated.
        /// </summary>
        public Vector2 Speed_Max
        {
            get { return generator.Speed_Max; }
            set { generator.Speed_Max = value; }
        }

        /// <summary>
        /// The minimum initial acceleration with which the cloud will be generated.
        /// </summary>
        public Vector2 Accel_Min
        {
            get { return generator.Accel_Min; }
            set { generator.Accel_Min = value; }
        }

        /// <summary>
        /// The maximum initial acceleration with which the cloud will be generated.
        /// </summary>
        public Vector2 Accel_Max
        {
            get { return generator.Accel_Max; }
            set { generator.Accel_Max = value; }
        }

        #region Cloud Frequencies

        // maybe it's just me, but random seems to work nicer with wider ranges.
        private const uint magicnumber = 11;

        /// <summary>
        /// Probability of a BigCloud being spawned out of TotalFrequency.
        /// </summary>
        public uint BigFrequency
        {
            get { return bigfrequency / magicnumber; }
            set { bigfrequency = value * magicnumber; }
        }
        private uint bigfrequency;

        /// <summary>
        /// Probability of a BigCloud being spawned out of TotalFrequency.
        /// </summary>
        public uint SmallFrequency
        {
            get { return smallfrequency / magicnumber; }
            set { smallfrequency = value * magicnumber; }
        }
        private uint smallfrequency;

        /// <summary>
        /// Probability of a BigCloud being spawned out of TotalFrequency.
        /// </summary>
        public uint SnowFrequency
        {
            get { return snowfrequency / magicnumber; }
            set { snowfrequency = value * magicnumber; }
        }
        private uint snowfrequency;

        /// <summary>
        /// Returns Big + Small + Snow frequency.
        /// </summary>
        public uint TotalFrequency
        {
            get { return bigfrequency + smallfrequency + snowfrequency; }
            private set { TotalFrequency = value; }
        }
        #endregion

        #endregion

        #region Public Methods

        /// <summary>
        /// Creates and initializes the CloudListGenerator.
        /// </summary>
        /// <param name="random">The RandomPlus random number generator.</param>
        /// <param name="active">Determines whether update runs.</param>
        /// <param name="frequency_min">How many milliseconds minimum before a new cloud is generated.</param>
        /// <param name="frequency_max">How many milliseconds maximum before a new cloud is generated.</param>
        /// <param name="y_coordinate">The Y coordinate at which the cloud's location will be set.</param>
        /// <param name="left_bound">The left X coordinate bound within which the cloud's location will be set.</param>
        /// <param name="right_bound">The right X coordinate bound within which the cloud's location will be set.</param>
        /// <param name="speed_min">The minimum initial speed with which the cloud will be generated.</param>
        /// <param name="speed_max">The maximum initial speed with which the cloud will be generated.</param>
        /// <param name="accel_min">The minimum initial acceleration with which the cloud will be generated.</param>
        /// <param name="accel_max">The maximum initial acceleration with which the cloud will be generated.</param>
        /// <param name="big">Probability of a BigCloud being spawned.</param>
        /// <param name="small">Probability of a SmallCloud being spawned.</param>
        /// <param name="snow">Probability of a SnowCloud being spawned.</param>
        public CloudListGenerator(RandomPlus random, bool active, int frequency_min, int frequency_max,
            float y_coordinate, float left_bound, float right_bound,
            Vector2 speed_min, Vector2 speed_max, Vector2 accel_min, Vector2 accel_max, uint big, uint small, uint snow)
        {
            this.random = random;

            Active = active;

            generator = new Generator(random, frequency_min, frequency_max,
                y_coordinate, left_bound, right_bound, speed_min, speed_max,
                accel_min, accel_max);

            BigFrequency = big;
            SmallFrequency = small;
            SnowFrequency = snow;
        }

        /// <summary>
        /// Updates the CloudListGenerator
        /// </summary>
        /// <param name="gametime">Provides a snapshot of timing values.</param>
        public void Update(GameTime gametime)
        {
            generator.Update(gametime);
            if (generator.Generated)
                Generate();
        }

        public void SpawnCloudAt(Vector2 position, CloudType type)
        {
            nextcloud = type;
            Cloud cloud = Recycle();
            if (cloud == null)
            {
                cloud = NewCloud();
                AddLast(cloud);
            }
            cloud.isAlive = true;
            cloud.position = position;
            cloud.velocity = new Vector2(generator.Speed.X, generator.Speed.Y);
            cloud.acceleration = new Vector2(generator.Acceleration.X, generator.Acceleration.Y);

        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Recycles clouds if it can. If not, creates new clouds and appends to list.
        /// </summary>
        private void Generate()
        {
            RandomizeCloud();
            Cloud cloud = Recycle();
            if (cloud == null)
            {
                cloud = NewCloud();
                AddLast(cloud);
            }
            cloud.isAlive = true;
            cloud.midPosition(new Vector2(generator.Position.X, generator.Position.Y));
            cloud.velocity = new Vector2(generator.Speed.X, generator.Speed.Y);
            cloud.acceleration = new Vector2(generator.Acceleration.X, generator.Acceleration.Y);
        }

        /// <summary>
        /// Creates a new cloud of the correct type.
        /// Returns null if nextcloud isn't set (Should never happen)
        /// </summary>
        /// <returns>The new cloud created</returns>
        private Cloud NewCloud()
        {
            switch (nextcloud)
            {
                case CloudType.Big:
                    return new BigCloud();
                case CloudType.Small:
                    return new SmallCloud();
                case CloudType.Snow:
                    return new SnowCloud();
                default:
                    return null;
            }
        }

        /// <summary>
        /// Searches for a cloud of the correct type whose isAlive == false.
        /// Returns null if no dead clouds of correct type are found.
        /// </summary>
        /// <returns>The found cloud or null.</returns>
        private Cloud Recycle()
        {
            Cloud deadcloud = null;
            bool breakloop = false;
            foreach (Cloud cloud in this)
            {
                if (!cloud.isAlive)
                {
                    switch (nextcloud)
                    {
                        case CloudType.Big:
                            if (cloud is BigCloud)
                            {
                                deadcloud = cloud;
                                breakloop = true;
                            }
                            break;
                        case CloudType.Small:
                            if (cloud is SmallCloud)
                            {
                                deadcloud = cloud;
                                breakloop = true;
                            }
                            break;
                        case CloudType.Snow:
                            if (cloud is SnowCloud)
                            {
                                deadcloud = cloud;
                                breakloop = true;
                            }
                            break;
                    }
                    if (breakloop)
                        break;
                }
            }
            return deadcloud;
        }

        /// <summary>
        /// Randomly determines next cloud to be spawned based on big, small, and snow frequencies.
        /// Sets nextcloud to type to be spawned.
        /// </summary>
        private void RandomizeCloud()
        {
            int target = random.Next((int)TotalFrequency);
            Console.WriteLine("Target is: " + target);
            Console.WriteLine("Total Frequency is: " + TotalFrequency);
            Console.WriteLine("Big Frequency is: " + bigfrequency);
            Console.WriteLine("Small Frequency is: " + smallfrequency);
            Console.WriteLine("Snow Frequency is: " + snowfrequency);
            target -= (int)bigfrequency;
            Console.WriteLine("Target after -= Big Frequency is: " + target);
            if (target < 0)
            {
                nextcloud = CloudType.Big;
                Console.WriteLine("Next cloud set to Big.");
            }
            else
            {
                target -= (int)smallfrequency;
                Console.WriteLine("Target after -= Small Frequency is: " + target);
                if (target < 0)
                {
                    nextcloud = CloudType.Small;
                    Console.WriteLine("Next cloud set to Small.");
                }
                else
                {
                    nextcloud = CloudType.Snow;
                    Console.WriteLine("Next cloud set to Snow.");
                }
            }
            Console.WriteLine();
        }

        #endregion
    }
}

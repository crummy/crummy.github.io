﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    /// <summary>
    /// Provides data for timing and randomization of units.
    /// When a new unit needs to be generated, will set Position, Speed, and Acceleration.
    /// to randomly generated amounts within parameters and will set Generated to true.
    /// Make sure to explicitly copy components of Position, Speed, and Acceleration.
    /// </summary>
    class Generator
    {
        private int clock; //Counts down milliseconds until spawn of new units.
        private RandomPlus random; //For use in Generate and ResetClock.

        #region Properties
        /// <summary>
        /// Signals that new data has been generated and a new unit should be generated.
        /// </summary>
        public bool Generated { get; private set; }

        /// <summary>
        /// How many milliseconds minimum before a new unit is generated.
        /// </summary>
        public int Frequency_Min { get; set; }

        /// <summary>
        /// How many milliseconds maximum before a new unit is generated.
        /// </summary>
        public int Frequency_Max { get; set; }

        /// <summary>
        /// The XY vector at which the new unit should be generated.
        /// </summary>
        public Vector2 Position { get; private set; }

        /// <summary>
        /// The Y coordinate at which the unit's location will be set.
        /// Isn't random.
        /// </summary>
        public float Y_Coordinate { get; set; }

        /// <summary>
        /// The left X coordinate bound within which the unit's location will be set.
        /// </summary>
        public float Left_Bound { get; set; }

        /// <summary>
        /// The right X coordinate bound within which the unit's location will be set.
        /// </summary>
        public float Right_Bound { get; set; }

        /// <summary>
        /// The initial speed with which the new unit should be generated.
        /// </summary>
        public Vector2 Speed { get; private set; }

        /// <summary>
        /// The minimum initial speed with which the unit will be generated.
        /// </summary>
        public Vector2 Speed_Min { get; set; }

        /// <summary>
        /// The maximum initial speed with which the unit will be generated.
        /// </summary>
        public Vector2 Speed_Max { get; set; }

        /// <summary>
        /// The initial acceleration with which the new unit should be generated.
        /// </summary>
        public Vector2 Acceleration { get; private set; }

        /// <summary>
        /// The minimum initial acceleration with which the unit will be generated.
        /// </summary>
        public Vector2 Accel_Min { get; set; }

        /// <summary>
        /// The maximum initial acceleration with which the unit will be generated.
        /// </summary>
        public Vector2 Accel_Max { get; set; }
        #endregion

        #region Public Methods

        /// <summary>
        /// Creates and initializes the Generator.
        /// </summary>
        /// <param name="random">The RandomPlus random number generator.</param>
        /// <param name="active">Determines whether update runs.</param>
        /// <param name="frequency_min">How many milliseconds minimum before a new unit is generated.</param>
        /// <param name="frequency_max">How many milliseconds maximum before a new unit is generated.</param>
        /// <param name="y_coordinate">The Y coordinate at which the unit's location will be set.</param>
        /// <param name="left_bound">The left X coordinate bound within which the unit's location will be set.</param>
        /// <param name="right_bound">The right X coordinate bound within which the unit's location will be set.</param>
        /// <param name="speed_min">The minimum initial speed with which the unit will be generated.</param>
        /// <param name="speed_max">The maximum initial speed with which the unit will be generated.</param>
        /// <param name="accel_min">The minimum initial acceleration with which the unit will be generated.</param>
        /// <param name="accel_max">The maximum initial acceleration with which the unit will be generated.</param>
        public Generator(RandomPlus random, int frequency_min, int frequency_max,
            float y_coordinate, float left_bound, float right_bound,
            Vector2 speed_min, Vector2 speed_max, Vector2 accel_min, Vector2 accel_max)
        {
            this.random = random;
            Generated = false;

            Frequency_Min = frequency_min;
            Frequency_Max = frequency_max;
            Y_Coordinate = y_coordinate;
            Left_Bound = left_bound;
            Right_Bound = right_bound;
            Speed_Min = speed_min;
            Speed_Max = speed_max;
            Accel_Min = accel_min;
            Accel_Max = accel_max;

            ResetClock();
            Generate();
        }

        /// <summary>
        /// Updates the Generator
        /// </summary>
        /// <param name="gametime">Provides a snapshot of timing values.</param>
        public void Update(GameTime gametime)
        {
            Generated = false;
            if (CountDown(gametime.ElapsedGameTime.Milliseconds))
            {
                ResetClock();
                Generate();
            }
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Recycles units if it can. If not, creates new units and appends to list.
        /// </summary>
        private void Generate()
        {
            Position = new Vector2(random.NextFloat(Left_Bound, Right_Bound), Y_Coordinate);
            Speed = new Vector2(random.NextFloat(Speed_Min.X, Speed_Max.X), random.NextFloat(Speed_Min.Y, Speed_Max.Y));
            Acceleration = new Vector2(random.NextFloat(Accel_Min.X, Accel_Max.X), random.NextFloat(Accel_Min.Y, Accel_Max.Y));
            Generated = true;
        }

        /// <summary>
        /// Resets the clock to a number between Frequency_Min and Frequency_Max
        /// </summary>
        private void ResetClock()
        {
            clock = random.Next(Frequency_Min, Frequency_Max);
        }

        /// <summary>
        /// Decrements the clock by the amount and returns whether it has reached zero.
        /// </summary>
        /// <param name="amount">Milliseconds to decrement the clock by.</param>
        /// <returns>Whether the clock has reached zero.</returns>
        private bool CountDown(int amount)
        {
            clock -= amount;
            return (clock <= 0);
        }
        #endregion
    }
}

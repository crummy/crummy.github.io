﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    interface IUnitGenerator
    {
        #region Fields and Properties

        /// <summary>
        /// Determines whether update runs.
        /// </summary>
        bool Active { get; set; }

        /// <summary>
        /// How many milliseconds minimum before a new unit is generated.
        /// </summary>
        int Frequency_Min { get; set; }

        /// <summary>
        /// How many milliseconds maximum before a new unit is generated.
        /// </summary>
        int Frequency_Max { get; set; }

        /// <summary>
        /// The Y coordinate at which the unit's location will be set.
        /// </summary>
        float Y_Coordinate { get; set; }

        /// <summary>
        /// The left X coordinate bound within which the unit's location will be set.
        /// </summary>
        float Left_Bound { get; set; }

        /// <summary>
        /// The right X coordinate bound within which the unit's location will be set.
        /// </summary>
        float Right_Bound { get; set; }

        /// <summary>
        /// The minimum initial speed with which the unit will be generated.
        /// </summary>
        Vector2 Speed_Min { get; set; }

        /// <summary>
        /// The maximum initial speed with which the unit will be generated.
        /// </summary>
        Vector2 Speed_Max { get; set; }

        /// <summary>
        /// The minimum initial acceleration with which the unit will be generated.
        /// </summary>
        Vector2 Accel_Min { get; set; }

        /// <summary>
        /// The maximum initial acceleration with which the unit will be generated.
        /// </summary>
        Vector2 Accel_Max { get; set; }
        #endregion

        #region Public Methods
        /// <summary>
        /// Updates the generator.
        /// Does not update the units held.
        /// </summary>
        void Update(GameTime gametime);
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    public class Rope : Unit
    {
        #region Fields

        /// <summary>
        /// Length of the rope in units (pixels)
        /// </summary>
        public float length;
        private int numberOfSegments = 20;
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        private static Texture2D texture;

        #endregion

        #region Construction, initialization
        /// <summary>
        /// Creates a new rope
        /// </summary>
        /// <param name="length">Length of the rope in units (pixels)</param>
        public Rope(float length) : base()
        {
            this.length = length;
        }
   
        public void Initialize()
        {
            setTexture("game/units/rope/ropesegment");
            origin = midPosition();
        }
        #endregion

        #region Draw
        public void Draw(Vector2 start, Vector2 end)
        {
            Vector2 toEnd = Vector2.Subtract(end, start);
            numberOfSegments = (int)toEnd.Length() / height();
            float length = height(); // Distance between each segment
            rotation = (float)Math.Atan2(toEnd.Y, toEnd.X) + MathHelper.PiOver2;
            toEnd.Normalize();
            for (int i = 0; i < numberOfSegments; i++)
                spriteBatch.Draw(texture, Vector2.Add(start, Vector2.Multiply(toEnd, length*i)), null, Color.White * alpha, rotation, origin, scale, SpriteEffects.FlipHorizontally, globals.rope_drawLayer);
        }
        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class SmallCloud : Cloud 
    {

        #region Fields
        private static Texture2D texture;
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        #endregion
                 
        #region Constructor, initalization
        public void Initialize()
        {
            setTexture("game/units/clouds/smallcloud");
        }


        /// <summary>
        /// Constructor.
        /// </summary>
        public SmallCloud() : base()
        {
            minTemp = 30;
            tempCoolingFactor = -4;
            setTexture("game/units/clouds/smallcloud");
            origin = new Vector2(width() / 2, height() / 2);
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class BigCloud : Cloud
    {
        #region Fields
        private static Texture2D texture;
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        #endregion

        #region Constructor, initalization
        public void Initialize()
        {
            setTexture("game/units/clouds/bigcloud");
        }

      
        /// <summary>
        /// Constructor.
        /// </summary>
        public BigCloud() : base()
        {
            setTexture("game/units/clouds/bigcloud");
            minTemp = 30;
            tempCoolingFactor = -4;
            position = new Vector2(400, 400);
            origin = new Vector2(width() / 2, height() / 2);
        }
        #endregion
    }
}

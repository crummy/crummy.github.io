﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class SnowCloud : Cloud
    {
        #region Fields
        private static Texture2D texture;
        public static Texture2D snowTexture;
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        //public bool snow = false;
        #endregion

        #region Constructor, initalization
        public void Initialize()
        {

        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public SnowCloud() : base()
        {
            msPerFrame = 200;
            frames = 2;
            frameWidth = 236;
            frameHeight = 100;
            tempCoolingFactor = -6;
            minTemp = 0;
            setTexture("game/units/clouds/snowcloud");
            snowTexture = game.Content.Load<Texture2D>("game/units/clouds/AnimateSnow3");
            origin = new Vector2(width() / 2, height() / 2);
            
        }
        #endregion

        public override void Draw()
        {
            spriteBatch.Draw(snowTexture,
                position,
                new Rectangle(frameWidth * currentFrame,
                    0,
                    width(), height() + 44),
                Color.White * globals.cloudTransparency, rotation, origin, scale, SpriteEffects.None, drawLayer);

                spriteBatch.Draw(Texture,
                    position,
                    new Rectangle(0,
                        0,
                        width(), height()),
                    Color.White * globals.cloudTransparency, rotation, origin, scale, SpriteEffects.None, drawLayer);
            
            base.Draw();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    abstract class Cloud : Unit
    {
        public static Vector2 wind = new Vector2(0,0);
        public int minTemp; // Minimum temperature this cloud will bring the player to
        public int tempCoolingFactor;
        private int msSinceCloudCreation = 0;
        protected float shadow_drawLayer;
 

        /// <summary>
        /// Constructor.
        /// </summary>
        public Cloud() : base()
        {
            scale = 1;
            origin = new Vector2(width() / 2, height() / 2);
            bottomDrawLayer = globals.cloud_bottomDrawLayer;
            topDrawLayer = globals.cloud_topDrawLayer;
        }

        /// <summary>
        /// Update - for clouds, makes them float gently
        /// </summary>
        /// <param name="gameTime">gametime</param>
        public override void Update(GameTime gameTime)
        {
            msSinceCloudCreation += gameTime.ElapsedGameTime.Milliseconds;
            scale = 1 + 0.05f * (float)Math.Sin(msSinceCloudCreation * 0.001f);
            position += wind;
            base.Update(gameTime);
        }

        protected override void SetDrawLayer()
        {
            base.SetDrawLayer();
            shadow_drawLayer = (globals.cloudshadow_topDrawLayer - globals.cloudshadow_bottomDrawLayer) * position.Y / game.Window.ClientBounds.Height;
            shadow_drawLayer = globals.cloudshadow_bottomDrawLayer + shadow_drawLayer;
        }

        public override Rectangle getBoundingBox()
        {
            return new Rectangle((int)(position.X - origin.X), (int)(position.Y - origin.Y), width(), height());
        }
        public Rectangle getShadowBoundingBox()
        {
            return new Rectangle((int)(position.X - origin.X + globals.cloudHeight), (int)(position.Y - origin.Y + globals.cloudHeight), width(), height());
        }

        /// <summary>
        /// Position of center of unit
        /// </summary>
        /// <returns>Vector to center of unit</returns>
        public override Vector2 midPosition()
        {
            return new Vector2(position.X, position.Y);
        }

        #region Draw
        public override void Draw()
        {
            // draw shadow
            spriteBatch.Draw(Texture,
                new Vector2(position.X + globals.cloudHeight, position.Y + globals.cloudHeight),
                null,
                Color.Black * globals.cloudShadowTransparency,
                rotation,
                origin,
                1,
                SpriteEffects.None,
                shadow_drawLayer);
            // draw cloud
            spriteBatch.Draw(Texture,
                position,
                new Rectangle(frameWidth * currentFrame,
                    0,
                    width(), height()),
                Color.White * globals.cloudTransparency, rotation, origin, scale, SpriteEffects.None, drawLayer);
        }
        #endregion
    }
}

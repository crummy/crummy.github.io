﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Audio;

namespace PenguinPull
{
    class IceFloe : Unit
    {
        #region Fields
        public static readonly Vector2 tetherOffset = new Vector2(0, -10);

        private SoundEffect growSound;
        private SoundEffect shrinkSound;

        #region Constants
        const int DEFAULTPOSITIONX = 100;
        const int DEFAULTPOSITIONY = 200;

        public const float defaultTemp = 25;
        public const float maxTemp = 100;
        public const float minTemp = 0;
        public const float BigTemp = 80;
        public const float MedTemp = 50;

        private const int smallMaxPenguins = 1;
        private const int medMaxPenguins = 3;
        private const int bigMaxPenguins = 5;

        private const int smallFrameWidth = 64;
        private const int medFrameWidth = 120;
        private const int bigFrameWidth = 200;

        private const int smallFrameHeight = 44;
        private const int medFrameHeight = 73;
        private const int bigFrameHeight = 114;
        #endregion

        #region Current
        public float currentTemp = 25;
        public int penguinCount = 2;
        private int currentMaxPenguins = 3;
        #endregion

        #region Size
        private enum size { small, medium, big }
        private size icefloeSize = size.medium;
        private size lastSize = size.small;
        #endregion

        #region Textures
        private static Texture2D texture;
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        private static Texture2D bigTexture;
        private static Texture2D medTexture;
        private static Texture2D smallTexture;
        #endregion

        private Penguin penguin;
        private LinkedList<Vector2> penguinPositions;
        private LinkedList<Vector2> penguinPositionsMed;
        private LinkedList<Vector2> penguinPositionsSmall;
        private LinkedList<Vector2> penguinPositionsLarge;

        public event EventHandler<gameoverEventArgs> gameOver;
        public event EventHandler<EventArgs> haltGame;

        int msSincePenguinLost = 10000;
        int msSinceSizeChange = 10000;
        #endregion
        
        #region Initialization
        public void Initialize()
        {
            bigTexture = game.Content.Load<Texture2D>("game/units/ice/largeice");
            medTexture = game.Content.Load<Texture2D>("game/units/ice/penguinice5");
            smallTexture = game.Content.Load<Texture2D>("game/units/ice/smallice");
            growSound = game.Content.Load<SoundEffect>("game/units/ice/grow");
            shrinkSound = game.Content.Load<SoundEffect>("game/units/ice/shrink");
            penguin.Initialize();
            texture = medTexture;
            bottomDrawLayer = globals.onwater_bottomDrawLayer;
            topDrawLayer = globals.onwater_topDrawLayer;
        }

        public IceFloe() : this(DEFAULTPOSITIONX, DEFAULTPOSITIONY) { }

        /// <summary>
        /// Constructor.
        /// </summary>
        public IceFloe(int xPos, int yPos) : base()
        {
            position = new Vector2(xPos, yPos);
            msPerFrame = 500;
            frames = 1;
            penguinPositions = new LinkedList<Vector2>();
            penguinPositionsSmall = new LinkedList<Vector2>();
            penguinPositionsMed = new LinkedList<Vector2>();
            penguinPositionsLarge = new LinkedList<Vector2>();
     
            //small ice floe penguin loc
            penguinPositionsSmall.AddFirst(new Vector2(10, -40));

            //medium floe penguin loc
            penguinPositionsMed.AddLast(new Vector2(32, -35));
            penguinPositionsMed.AddLast(new Vector2(10, -25));
            penguinPositionsMed.AddLast(new Vector2(63, -18));
            
            //large floe penguin loc
            penguinPositionsLarge.AddLast(new Vector2(30, 10));
            penguinPositionsLarge.AddLast(new Vector2(63, -18));
            penguinPositionsLarge.AddLast(new Vector2(75, 8));
            penguinPositionsLarge.AddLast(new Vector2(100, -18));
            penguinPositionsLarge.AddLast(new Vector2(128, 10));
            penguin = new Penguin();

            penguinPositions = penguinPositionsMed;
            sizeIsMedium();
        }
        #endregion

        public void underCloud(Cloud cloud)
        {
            if (currentTemp > cloud.minTemp)
                currentTemp += cloud.tempCoolingFactor;
        }
        public void notUnderCloud()
        {
            if (currentTemp < maxTemp)
                currentTemp += globals.tempHeatingFactor;
        }

        /// <summary>
        /// Sets the size to small.
        /// </summary>
        private void sizeIsSmall()
        {
            penguinPositions = penguinPositionsSmall;
            icefloeSize = size.small;
            texture = smallTexture;
            currentMaxPenguins = smallMaxPenguins;
            frameWidth = smallFrameWidth;
            frameHeight = smallFrameHeight;
            //small ice floe penguin loc
            //What is the point of this condition?
            if (icefloeSize == size.small)
            {
               // penguinPositions.AddLast(new Vector2(10, -40));
               // while (penguinPositions.First() != penguinPositions.Last())
                   // penguinPositions.RemoveFirst();
                
            }
        }

        /// <summary>
        /// Sets the size to medium.
        /// </summary>
        private void sizeIsMedium()
        {
            penguinPositions = penguinPositionsMed;
            icefloeSize = size.medium;
            texture = medTexture;
            currentMaxPenguins = medMaxPenguins;
            frameWidth = medFrameWidth;
            frameHeight = medFrameHeight;
        }

        /// <summary>
        /// Sets the size to big.
        /// </summary>
        private void sizeIsBig()
        {
            penguinPositions = penguinPositionsLarge;
            icefloeSize = size.big;
            texture = bigTexture;
            currentMaxPenguins = bigMaxPenguins;
            frameWidth = bigFrameWidth;
            frameHeight = bigFrameHeight;
        }

        /// <summary>
        /// Grows the icefloe to the next larger size.
        /// </summary>
        public void grow()
        {
            msSinceSizeChange = 0;
            if (icefloeSize == size.medium)
            {
                sizeIsBig();
                growSound.Play(globals.volume, 0f, 0f);
                lastSize = size.medium;
                haltGame(this, new EventArgs());
            }
            else if (icefloeSize == size.small)
            {
                growSound.Play(globals.volume, 0f, 0f);
                sizeIsMedium();
                lastSize = size.small;
                haltGame(this, new EventArgs());
            }
        }

        /// <summary>
        /// Shrinks the icefloe to the next smaller size.
        /// gameover if already small.
        /// </summary>
        public void shrink()
        {
            msSinceSizeChange = 0;
            if (icefloeSize == size.small)
            {
                gameOver(this, new gameoverEventArgs("The ice floe\n   melted"));
            }
            else if (icefloeSize == size.medium)
            {
                shrinkSound.Play(globals.volume, 0f, 0f);
                sizeIsSmall();
                lastSize = size.medium;
                haltGame(this, new EventArgs());
                
            }
            else if (icefloeSize == size.big)
            {
                shrinkSound.Play(globals.volume, 0f, 0f);
                lastSize = size.big;
                sizeIsMedium();
                haltGame(this, new EventArgs());
            }
        }

        /// <summary>
        /// Update the icefloe
        /// </summary>
        /// <param name="gameTime">Provides timing.</param>
        /// <param name="boat">The boat the icefloe is following.</param>
        public void Update(GameTime gameTime, TugBoat boat)
        {
            base.Update(gameTime);
            
            if (currentTemp <= minTemp && icefloeSize != size.big)
            {
                grow();
                currentTemp = maxTemp - 80;
            }
            else if (currentTemp >= maxTemp)
            {
                shrink();
                currentTemp = minTemp + 1;
            }

            if (penguinCount > currentMaxPenguins)
                losePenguin_shrink(penguinCount - currentMaxPenguins);
            base.Update(gameTime);
        }

        public void UpdateWhileHalted(GameTime gameTime)
        {
            msSincePenguinLost += gameTime.ElapsedGameTime.Milliseconds;
            msSinceSizeChange += gameTime.ElapsedGameTime.Milliseconds;
        }

        /// <summary>
        /// Base draw, then draw penguins.
        /// </summary>
        public override void Draw()
        {
            if ((msSinceSizeChange < globals.haltTime) && (msSinceSizeChange % 3 == 0)) // blink 
            {
                icefloeBlink();
            }
            else
            {
                base.Draw();
            }
            for (int i = 0; i < penguinCount; i++)
            {
                penguin.position = penguinPositions.ElementAt(i) + position;
                penguin.alpha = alpha;
                penguin.Draw();
            }
            if (msSincePenguinLost < globals.haltTime) // show blinking penguin
            {
                penguin.position = position;
                penguin.position.X += width() + 30;
                penguin.rotation = 1;
                if (msSincePenguinLost % 3 == 0)
                    penguin.Draw();
                penguin.rotation = 0;

            }
        }

        private void icefloeBlink()
        {
            if (lastSize == size.small && icefloeSize == size.medium)
            {
                sizeIsSmall();
                base.Draw();
                sizeIsMedium();
            }
            else if (lastSize == size.medium && icefloeSize == size.big)
            {
                sizeIsMedium();
                base.Draw();
                sizeIsBig();
            }
            else if (lastSize == size.medium && icefloeSize == size.small)
            {
                sizeIsMedium();
                base.Draw();
                sizeIsSmall();
            }
            else if (lastSize == size.big && icefloeSize == size.medium)
            {
                sizeIsBig();
                base.Draw();
                sizeIsMedium();
            }
        }

        /// <summary>
        /// Lose a penguin, lose the game if no penguins left.
        /// Method to be called by collisions.
        /// </summary>
        internal void losePenguin()
        {
            msSincePenguinLost = 0;
            penguinCount--;
            if (penguinCount == 0)
                gameOver(this, new gameoverEventArgs("The penguins\n  fell off"));
        }

        /// <summary>
        /// Lose multiple penguins, does not throw gameover.
        /// Shrink() is assumed to have thrown gameover if no penguins left.
        /// Method to be called by Update.
        /// </summary>
        /// <param name="penguins">The number of penguins to lose.</param>
        protected void losePenguin_shrink(int penguins)
        {
            msSincePenguinLost = 0;
            penguinCount -= penguins;
        }

        internal bool gainPenguin()
        {
            if (penguinCount < currentMaxPenguins)
            {
                penguinCount++;
                return true;
            }
            else // too many penguins
            {
                return false;
            }
        }
    }

    /// <summary>
    /// Throws condition for ending game.
    /// </summary>
    class gameoverEventArgs : EventArgs {
        public string reason;
        /// <summary>
        /// Event ends game, contains reason for losing.
        /// </summary>
        /// <param name="reason">The reason for losing the game.</param>
        public gameoverEventArgs(string reason)
        {
            this.reason = reason;
        }
    }
}

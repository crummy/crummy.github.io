﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace PenguinPull
{
    /// <summary>
    /// Base class from which all units inherit
    /// </summary>
    public abstract class Unit
    {
        #region Fields

        /// <summary>
        /// The 2D texture which represents this unit
        /// </summary>
        public virtual Texture2D Texture {
            get {
                return game.Content.Load<Texture2D>("undefined");
            }
            set
            {
            }
        }

        // Values for animation
        protected int msPerFrame = 100; // in ms
        protected int msSinceLastFrame = 0;
        public int frames = 0;
        public int currentFrame = 0;
        public int frameWidth = 0;  // width and height of a frame, not the texture
        public int frameHeight = 0;
        public float scale = 1;

        // Values for layering
        protected float bottomDrawLayer = 0.9f;
        protected float topDrawLayer = 1.0f;
        public float drawLayer;

        /// <summary>
        /// Reference to the Game that this unit is attached to.
        /// </summary>
        public static Game game;

        /// <summary>
        /// Reference to the SpriteBatch for units to draw themselves on.
        /// </summary>
        public static SpriteBatch spriteBatch;

        /// <summary>
        /// This unit's top left position on the screen 
        /// </summary>
        public Vector2 position;

        /// <summary>
        /// This unit's speed in pixels per second.
        /// </summary>
        public Vector2 velocity;

        /// <summary>
        /// This units acceleration in pixels per second squared.
        /// </summary>
        public Vector2 acceleration;

        /// <summary>
        /// This unit's rotation in radians.
        /// </summary>
        public float rotation;

        /// <summary>
        /// The origin of the unit, to be used when drawing. Usually 0,0, except for clouds
        /// </summary>
        public Vector2 origin;

        /// <summary>
        /// The unit's color (tint)
        /// </summary>
        public Color color;

        /// <summary>
        /// (0 to 1)
        /// The unit's transparancy. 0 is invisible, 1 is fully opaque.
        /// </summary>
        public float alpha;

        /// <summary>
        /// Units that are not alive should not be drawn or tested for collisions.
        /// </summary>
        public bool isAlive;

        /// <summary>
        /// How much the bounding box is shrunk from the size of the texture/frame, per pixel on each side.
        /// </summary>
        protected int boundingboxShrinkFactor = 4;

        
        
        #endregion

        #region Initialization

        public static void Initialize(Game gameRef, SpriteBatch sb)
        {
            game = gameRef;
            spriteBatch = sb;
        }

        /// <summary>
        /// Constructs a new unit.
        /// </summary>
        public Unit()
        {
            position = Vector2.Zero;
            velocity = Vector2.Zero;
            acceleration = Vector2.Zero;
            color = Color.White;
            alpha = 1.0f;
            rotation = 0.0f;
            isAlive = true;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Sets texture for unit, and sets bounding box.
        /// </summary>
        /// <param name="textureRef">Texture for unit</param>
        public void setTexture(string textureRef)
        {
            ContentManager content = game.Content;
            try
            {
                Texture = content.Load<Texture2D>(textureRef);
            }
            catch (Exception ex)
            {
                if (ex is ContentLoadException)
                {
                    Console.Error.WriteLine("Invalid Texture: " + textureRef);
                    try
                    {
                        Texture = content.Load<Texture2D>("undefined");
                    }
                    catch (ContentLoadException)
                    {
                        throw (new Exception("Missing the \"Undefined\" Texture: undefined"));
                    }
                }
                else if (ex is ArgumentNullException)
                {
                    Console.Error.WriteLine("Null Texture argument to Unit.SetTexture(string textureRef)\n" + ex.Message);
                    try
                    {
                        Texture = content.Load<Texture2D>("undefined");
                    }
                    catch (ContentLoadException)
                    {
                        throw (new Exception("Missing the \"Undefined\" Texture: undefined"));
                    }
                }
                else
                    throw;
            }
        }

        public virtual Rectangle getBoundingBox()
        {
            return new Rectangle((int)position.X + boundingboxShrinkFactor,
                (int)position.Y + boundingboxShrinkFactor,
                width() - boundingboxShrinkFactor * 2,
                height() - boundingboxShrinkFactor * 2);
        }

        /// <summary>
        /// Width of unit
        /// </summary>
        /// <returns>Width in pixels</returns>
        public virtual int width()
        {
            if (frameWidth == 0 && (Texture != null))
                return Texture.Width;
            else
                return frameWidth;
        }

        /// <summary>
        /// Height of unit
        /// </summary>
        /// <returns>Height in pixels</returns>
        public virtual int height()
        {
            if ((frameHeight == 0) && (Texture != null))
                return (int)(Texture.Height);
            else
                return frameHeight;
        }

        /// <summary>
        /// Gets position of center of unit
        /// </summary>
        /// <returns>Vector to center of unit</returns>
        public virtual Vector2 midPosition()
        {
            return new Vector2(position.X + width() / 2, position.Y + height() / 2);
        }
        /// <summary>
        /// Sets position of center of unit
        /// </summary>
        /// <returns>Vector to center of unit</returns>
        public virtual Vector2 midPosition(float x, float y)
        {
            position = new Vector2(x - width() / 2, y - height() / 2);
            return new Vector2(position.X + width() / 2, position.Y + height() / 2);
        }
        public virtual Vector2 midPosition(Vector2 newMid) { return midPosition(newMid.X, newMid.Y); }

        #endregion

        #region Update, Draw, and updated methods
        public virtual void Draw()
        {
            if (isAlive)
            {
                if (Texture == null)
                    setTexture(null);
                // draw image
                spriteBatch.Draw(Texture, position, new Rectangle(frameWidth * currentFrame, 0, width(), height()),
                    new Color(color.R, color.G, color.B) * alpha, rotation, origin, scale, SpriteEffects.None, drawLayer);
            }
        }

        public virtual void Update(GameTime gameTime)
        {
            MoveUnit();
            AnimateImage(gameTime);
            SetDrawLayer();
        }

        /// <summary>
        /// Move Unit downwards.
        /// </summary>
        protected virtual void MoveUnit()
        {
            velocity += acceleration;
            position += velocity;
        }

        /// <summary>
        /// Animates the sprite's image.
        /// </summary>
        protected virtual void AnimateImage(GameTime gameTime)
        {
            msSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;
            if (msSinceLastFrame > msPerFrame)
            {
                msSinceLastFrame -= msPerFrame;
                currentFrame++;
                if (currentFrame > frames)
                {
                    currentFrame = 0;
                }
            }
        }

        /// <summary>
        /// Sets the layer for the image to be drawn at.
        /// </summary>
        protected virtual void SetDrawLayer()
        {
            drawLayer = (topDrawLayer - bottomDrawLayer) * position.Y / game.Window.ClientBounds.Height;
            drawLayer = bottomDrawLayer + drawLayer;
        }

        #endregion
    }
}

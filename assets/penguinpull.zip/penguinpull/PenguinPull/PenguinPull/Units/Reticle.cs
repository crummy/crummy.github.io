﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class Reticle : Unit
    {
        #region Fields
        private float timeSinceMoved;
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        private Texture2D texture;
        #endregion

        #region Constructor, initialization
        /// <summary>
        /// Constructor.
        /// </summary>
        public Reticle() : base()
        {
            timeSinceMoved = 0;
            msPerFrame = 400;
            frames = 1;
            frameWidth = 36;
            frameHeight = 36;
            position = new Vector2(200, 200);
            drawLayer = globals.reticle_drawLayer;
        }

        public void Initialize()
        {
            setTexture("game/units/reticle");
            origin = new Vector2(width(), height());
        }
        #endregion

        #region Update (handles input!)
        public void Update(InputState inputState)
        {
            // Remove the reticle if the mouse hasn't moved for globals.reticleHideTime milliseconds
            if (inputState.CurrentMouseStates[0] != inputState.LastMouseStates[0])
            {
                if (!isAlive)
                    isAlive = true;
                position = new Vector2(inputState.CurrentMouseStates[0].X, inputState.CurrentMouseStates[0].Y);
                timeSinceMoved = 0;
            }
            else
            {
                timeSinceMoved += globals.timeSinceLastUpdate.ElapsedGameTime.Milliseconds;
                if (isAlive && timeSinceMoved >= globals.reticleHideTime)
                    isAlive = false;
            }
        }
        #endregion

    }
}

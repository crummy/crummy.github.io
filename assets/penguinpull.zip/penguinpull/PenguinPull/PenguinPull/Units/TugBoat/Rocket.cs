﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Audio;

namespace PenguinPull
{
    class Rocket : Unit
    {
        #region Fields
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        private static Texture2D texture;
        public event EventHandler<EventArgs> Exploded;
        public bool hasExploded;
        public Vector2 endPosition;
        public bool collidesWithClouds;
        public SoundEffect rocketInMotion;
        public SoundEffectInstance rocketInMotionInstance;
        public SoundEffect rocketExploded;
        
        ParticleSystem smoke;
        ParticleEmitter smokeemitter;
//        ParticleSystem sparks;
//        ParticleEmitter sparkemitter;

        #endregion

        #region Construction, initialization
        public void Initialize()
        {
            setTexture("game/units/tugboat/rocket");
            rocketInMotion = game.Content.Load<SoundEffect>("game/units/tugboat/static"); // http://www.freesound.org/samplesViewSingle.php?id=27428
            rocketExploded = game.Content.Load<SoundEffect>("game/units/tugboat/explosion"); // http://www.freesound.org/samplesViewSingle.php?id=18390
        }

        public Rocket(Vector2 startPosition, Vector2 endPosition) : base()
        {
            Initialize();
            frames = 0;
            frameWidth = 32;
            frameHeight = 60;
            isAlive = true;
            position = startPosition;
            this.endPosition = endPosition;
            acceleration = velocity = Vector2.Normalize(Vector2.Subtract(endPosition, position));
            rotation = (float)Math.Atan(velocity.X / (-velocity.Y));
            if (endPosition.Y > position.Y)
                rotation += (float)Math.PI;
            origin = new Vector2(width() / 2, height() / 2);
            collidesWithClouds = false;
            hasExploded = false;

            rocketInMotionInstance = rocketInMotion.CreateInstance();
            rocketInMotionInstance.Volume = globals.volume;
            rocketInMotionInstance.Play();

            smoke = new ParticleSystem(100, 450, .75f, 0, .1f, 1.25f);
            smoke.texture = game.Content.Load<Texture2D>("game/textures/smoke1");
            smokeemitter = new ParticleEmitter(smoke, 100, startPosition, 0, 12);

//            sparks = new ParticleSystem(100, 200, 1, .5f, .5f, .5f);
//            sparks.texture = game.Content.Load<Texture2D>("game/units/clouds/snow");
//            sparkemitter = new ParticleEmitter(sparks, 100, startPosition, 0, 5);

            drawLayer = globals.rocket_drawLayer;
        }

        /// <summary>
        /// Base constructor exists so that texture may be initialized.
        /// </summary>
        public Rocket() : base()
        {
            frames = 0;
            frameWidth = 32;
            frameHeight = 60;
            isAlive = false;
        }
        #endregion

        public override void Update(GameTime gameTime)
        {
            if (isAlive && !hasExploded) // If rocket is traveling to destination
            {
                Vector2 tempPosition = position;
                base.Update(gameTime);
                if (Vector2.Distance(position, endPosition) > Vector2.Distance(tempPosition, endPosition))
                {
                    rocketInMotionInstance.Stop();
                    rocketExploded.Play(globals.volume, 0f, 0f);
                    position = endPosition;
                    hasExploded = true;
                    Exploded(this, new EventArgs());
                }
                position.Y += globals.verticalSpeed;
                endPosition.Y += globals.verticalSpeed;
                smoke.Update(gameTime);
                smokeemitter.Update(gameTime, position);
//                sparks.Update(gameTime);
//                sparkemitter.Update(gameTime, position);
            }
            else if (isAlive && hasExploded)
            {
                smoke.Update(gameTime);
//                sparks.Update(gameTime);
            }
        }

        public override void Draw()
        {
            smoke.Draw(spriteBatch);
//            sparks.Draw(spriteBatch);
            if (!hasExploded)
                base.Draw();
        }

        protected override void SetDrawLayer() { } //Do nothing.

    }
}

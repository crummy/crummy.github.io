﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace PenguinPull
{
    class TugBoat : Unit
    {
        #region Fields
        const int DEFAULTPOSITIONX = 100;
        const int DEFAULTPOSITIONY = 100;
        internal const int FRAMEWIDTH = 100;
        internal const int FRAMEHEIGHT = 108;
        public static readonly Vector2 tetherOffset = new Vector2(0, 40);
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        private Texture2D texture;

        ParticleSystem puffs;
        ParticleEmitter emitter;
        #endregion
        
        #region Initialization

        /// <summary>
        /// Class Constructor.
        /// </summary>
        public void Initialize()
        {
            setTexture("game/units/tugboat/boat");
            puffs.texture = game.Content.Load<Texture2D>("game/textures/smoke1");
        }

        public TugBoat() : this(DEFAULTPOSITIONX, DEFAULTPOSITIONY) { }

        /// <summary>
        /// Instance Constructor.
        /// </summary>
        public TugBoat(int xPos, int yPos)
        {
            boundingboxShrinkFactor = 12;
            msPerFrame = 150;
            frameWidth = FRAMEWIDTH;
            frameHeight = FRAMEHEIGHT;
            frames = 1;
            position = new Vector2(xPos, yPos);
            velocity = Vector2.Zero;
            acceleration = Vector2.Zero;
            rotation = 0.0f;
            topDrawLayer = globals.onwater_topDrawLayer;
            bottomDrawLayer = globals.onwater_bottomDrawLayer;

            puffs = new ParticleSystem(10, 1500, .7f, 0, .5f, 2);
            emitter = new ParticleEmitter(puffs, 2, position, 0, 10);
        }
        #endregion

        public Vector2 getRocketLaunchPosition()
        {
            return new Vector2(position.X + width() / 2, position.Y + width() / 2);
        }

        #region Update
        // This is overriden so the tugboat no longer does position += velocity.
        public override void Update(GameTime gameTime)
        {
            AnimateImage(gameTime);
            SetDrawLayer();
            puffs.Update(gameTime);
            emitter.Update(gameTime, new Vector2(position.X + width() / 2, position.Y + 20));

            foreach (Particle puff in puffs.particles)
                puff.position += new Vector2(0, globals.verticalSpeed);
        }

        public override void Draw()
        {
            puffs.Draw(spriteBatch);
            base.Draw();
        }

        #endregion
    }
}

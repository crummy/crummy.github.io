﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class Particle : Unit
    {
        public float lifetime;
        public float timeSinceStart;
        private float startalpha;
        private float endalpha;
        private float startscale;
        private float endscale;

        public Particle()
        {
            isAlive = false;
            drawLayer = globals.rocket_drawLayer-.001f;
        }

        public void Initialize(Vector2 position, Vector2 velocity, Vector2 acceleration, float lifetime,
                                float startalpha, float endalpha, float startscale, float endscale)
        {
            isAlive = true;

            this.position = position;
            this.velocity = velocity;
            this.acceleration = acceleration;
            this.lifetime = lifetime;
            this.scale = this.startscale = startscale;
            this.endscale = endscale;
            this.alpha = this.startalpha = startalpha;
            this.endalpha = endalpha;
            this.origin = new Vector2(width(), height());

            this.timeSinceStart = 0.0f;
        }

        public override void Update(GameTime gameTime)
        {
            timeSinceStart += gameTime.ElapsedGameTime.Milliseconds;
            if (timeSinceStart > lifetime)
                isAlive = false;

            this.alpha = MathHelper.Lerp(startalpha, endalpha, timeSinceStart / lifetime);
            this.scale = MathHelper.Lerp(startscale, endscale, timeSinceStart / lifetime);
            this.position += Cloud.wind;

 	        base.Update(gameTime);
        }

        public override void Draw()
        {
            // why is this being called
        }
    }
}

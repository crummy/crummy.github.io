﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class PenguinPowerup : Obstacle
    {
        #region Fields
        private static Texture2D texture;
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        private Random random = new Random();
        private static bool initialized = false;
        #endregion

        #region Constructor, initalization
        public void Initialize()
        {
            setTexture("penguinpowerup");
            initialized = true;
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public PenguinPowerup()
            : base()
        {
            frameWidth = 63;
            frameHeight = 85;
            frames = 1;
            drawLayer = globals.penguinPowerup_drawLayer;
            if (!initialized)
                Initialize();
        }
        #endregion

        #region Update

        public override void Update(GameTime gameTime)
        {
            position += velocity;
            if (random.Next(50) < 1)
            {
                currentFrame++;
                if (currentFrame > frames)
                    currentFrame = 0;
            }
        }

        protected override void SetDrawLayer() { } //do nothing
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class Penguin : Obstacle
    {
        #region Fields
        private static Texture2D texture;
        public override Texture2D Texture { get { return texture; } set { texture = value; } }
        private Random random = new Random();
        #endregion

        #region Constructor, initalization
        public void Initialize()
        {
            setTexture("penguin");
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        public Penguin() : base()
        {
            frameWidth = 48;
            frameHeight = 56;
            frames = 1;
            drawLayer = globals.penguin_drawLayer;
        }
        #endregion

        #region Update

        public override void Update(GameTime gameTime)
        {
            position += velocity;
            if (random.Next(100) < 1)
            {
                currentFrame++;
                if (currentFrame > frames)
                    currentFrame = 0;
            }
        }

        protected override void SetDrawLayer() { } //do nothing
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class Whale : Obstacle
    {
        #region Fields
        public override Texture2D Texture { get { return base.Texture; } set { texture = value; } }
        private static Texture2D texture;
        private static Texture2D spoutTexture;
        public static float pushForce = 700; // How hard it pushes the boat away when a collision occurs.

        public int msSinceStart = 0;
        int msUponSurface = 2000; // Whale surfaces after 2s
        int msUponSink = 3500; // Whale sinks again later

        int spoutFrameWidth = 64;
        int spoutFrameHeight = 64;
        int spoutFrames = 2;
        int spoutCurrentFrame = 0;

        #endregion

        /// <summary>
        /// Constructor.
        /// </summary>
        public Whale() : base()
        {
            msSinceStart = 0;
            frames = 0;
            frameWidth = 132;
            frameHeight = 240;
            setTexture("game/units/obstacles/whale");
            spoutTexture = game.Content.Load<Texture2D>("game/units/obstacles/whalespout");
            bottomDrawLayer = globals.underwater_bottomDrawLayer;
            topDrawLayer = globals.underwater_topDrawLayer;
            alpha = 0.4f;
        }

        public override void Update(GameTime gameTime)
        {
            msSinceStart += gameTime.ElapsedGameTime.Milliseconds;
            base.Update(gameTime);

            spoutCurrentFrame++;
            if (spoutCurrentFrame > spoutFrames)
                spoutCurrentFrame = 0;
        }

        public override Rectangle getBoundingBox()
        {
            if (position.Y < -texture.Height)
                return new Rectangle((int)position.X, (int)position.Y, texture.Width / 2, texture.Height);
            if ((msSinceStart > msUponSurface) && (msSinceStart < msUponSink))
                return new Rectangle((int)position.X + 30, (int)position.Y + 114, 72, 115);
            else return new Rectangle(0, 0, 0, 0);
        }

        #region Draws
        public override void Draw()
        {
            // draw 
            spriteBatch.Draw(texture,
                position,
                new Rectangle(0,
                    0,
                    frameWidth, frameHeight),
                Color.White * alpha, rotation, Vector2.Zero, 1, SpriteEffects.None, drawLayer);
            if ((msSinceStart > msUponSurface) && (msSinceStart < msUponSink))
            {
                spriteBatch.Draw(texture,
                position,
                new Rectangle(frameWidth * 1,
                    0,
                    frameWidth, frameHeight),
                Color.White, rotation, Vector2.Zero, 1, SpriteEffects.None, drawLayer + .0001f);
                spriteBatch.Draw(spoutTexture,
                    new Vector2(position.X + width() / 2, position.Y + height() / 2 + 74),
                    new Rectangle(spoutFrameWidth * spoutCurrentFrame,
                        0,
                        spoutFrameWidth, spoutFrameHeight),
                    Color.White, 0, new Vector2(spoutFrameWidth / 2, spoutFrameHeight / 2),
                    1, SpriteEffects.None, drawLayer + .0002f);
            }
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class Iceberg : Obstacle
    {
        #region Fields
        public override Texture2D Texture { get { return base.Texture; } set { texture = value; } }
        private Texture2D texture;
        public static float pushForce = 700; // How hard it pushes the boat away when a collision occurs.
        #endregion

        #region Constructor, initialization
        /// <summary>
        /// Constructor.
        /// </summary>
        public Iceberg() : base()
        {
            msPerFrame = 400;
            boundingboxShrinkFactor = 12;
            frames = 1;
            frameWidth = 128;
            frameHeight = 98;
            setTexture("game/units/obstacles/iceberg");
            topDrawLayer = globals.onwater_topDrawLayer;
            bottomDrawLayer = globals.onwater_bottomDrawLayer;
        }

        public void Initialize()
        {
            setTexture("game/units/obstacles/iceberg");
        }
        #endregion

        #region Draws
        //SHOULDNT WE MAKE THIS DRAW JUST LIKE EVERY OTHER ANIMATED UNIT?
        public override void Draw()
        {
            spriteBatch.Draw(texture,
                position,
                new Rectangle(frameWidth * currentFrame,
                    0,
                    frameWidth, frameHeight),
                Color.White, rotation, Vector2.Zero, 1, SpriteEffects.None, drawLayer);
        }
        #endregion
    }
}

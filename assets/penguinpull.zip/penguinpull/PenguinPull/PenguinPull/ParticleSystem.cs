﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PenguinPull
{
    class ParticleSystem
    {
        /// <summary>
        /// Array of particles used
        /// </summary>
        public List<Particle> particles;

        private Queue<Particle> freeParticles;

        /// <summary>
        /// Texture for each particle
        /// </summary>
        public Texture2D texture;

        // lifetime of a particle in our system in ms
        private float lifetime;

        private float startalpha;
        private float endalpha;
        private float startscale;
        private float endscale;

        private Random rand = new Random();

        public ParticleSystem(int particleCount, float lifetime, float startalpha = 1, float endalpha = 1,
                                float startscale = 1, float endscale = 1)
        {
            particles = new List<Particle>(particleCount);
            freeParticles = new Queue<Particle>(particleCount);
            for (int i = 0; i < particleCount; i++)
            {
                particles.Add(new Particle());
                freeParticles.Enqueue(particles[i]);
            }
            this.lifetime = lifetime;
            this.startalpha = startalpha;
            this.endalpha = endalpha;
            this.startscale = startscale;
            this.endscale = endscale;
        }

        
        public void AddParticles(Vector2 where, Vector2 velocity, int count)
        {
            for (int i = 0; i < count; i++)
            {
                if (freeParticles.Count == 0)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        Particle newParticle = new Particle();
                        particles.Add(newParticle);
                        freeParticles.Enqueue(newParticle);
                    }
                }
                Particle p = freeParticles.Dequeue();
                InitializeParticle(p, where, velocity);
            }
        }

        /// <summary>
        /// InitializeParticle randomizes some properties for a particle, then
        /// calls initialize on it. It can be overriden by subclasses if they 
        /// want to modify the way particles are created. For example, 
        /// SmokePlumeParticleSystem overrides this function make all particles
        /// accelerate to the right, simulating wind.
        /// </summary>
        /// <param name="p">the particle to initialize</param>
        /// <param name="where">the position on the screen that the particle should be</param>
        /// <param name="velocity">The base velocity that the particle should have</param>
        private void InitializeParticle(Particle p, Vector2 where, Vector2 velocity)
        {
            velocity = new Vector2(0, 0);

            Vector2 acceleration = Vector2.Zero;

            // then initialize it with those random values. initialize will save those,
            // and make sure it is marked as active.
            p.Initialize(
                where,
                velocity,
                acceleration,
                lifetime,
                startalpha,
                endalpha,
                startscale,
                endscale);
        }

        public void Update(GameTime gameTime)
        {
            foreach (Particle p in particles)
            {
                if (p.isAlive)
                {
                    p.Update(gameTime);
                }
                else
                {
                    freeParticles.Enqueue(p);
                }
            }
        }

        public void Draw(SpriteBatch sb)
        {
            foreach (Particle p in particles)
            {
                if (!p.isAlive)
                    continue;
                //float normalizedLifetime = p.timeSinceStart / p.lifetime;

                //p.alpha = 4 * normalizedLifetime * (1 - normalizedLifetime);
                //p.alpha = 1 - p.timeSinceStart / p.lifetime;

                sb.Draw(texture, p.position, new Rectangle(0, 0, texture.Width, texture.Height),
                    new Color(p.color.R, p.color.G, p.color.B) * p.alpha, p.rotation, p.origin, p.scale, SpriteEffects.None, p.drawLayer);
            }
        }

        public int ActiveParticleCount()
        {
            return particles.Count - freeParticles.Count;
        }
    }
}

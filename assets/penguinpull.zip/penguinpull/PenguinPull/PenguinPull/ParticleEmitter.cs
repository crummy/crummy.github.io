﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    class ParticleEmitter
    {
        public Vector2 position;
        ParticleSystem particleSystem;
        RandomPlus rand;
        public float timeBetweenParticles;
        float timeLeftOver;
        private float minoffset;
        private float maxoffset;

        public ParticleEmitter(ParticleSystem particleSystem, float particlesPerSecond, Vector2 initialPosition,
                                float minoffset = 0, float maxoffset = 0)
        {
            this.particleSystem = particleSystem;
            this.rand = new RandomPlus();
            timeBetweenParticles = 1.0f / particlesPerSecond;
            position = initialPosition;
            this.minoffset = minoffset;
            this.maxoffset = maxoffset;
        }

        public void Update(GameTime gameTime, Vector2 newPosition)
        {
            float elapsedTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (elapsedTime > 0)
            {
                // Work out how fast we are moving.
                Vector2 velocity = (newPosition - position) / elapsedTime;

                // If we had any time left over that we didn't use during the
                // previous update, add that to the current elapsed time.
                float timeToSpend = timeLeftOver + elapsedTime;

                // Counter for looping over the time interval.
                float currentTime = -timeLeftOver;

                // Create particles as long as we have a big enough time interval.
                while (timeToSpend > timeBetweenParticles)
                {
                    currentTime += timeBetweenParticles;
                    timeToSpend -= timeBetweenParticles;

                    // Work out the optimal position for this particle. This will produce
                    // evenly spaced particles regardless of the object speed, particle
                    // creation frequency, or game update rate.
                    float mu = currentTime / elapsedTime;
                    float angle = rand.NextFloat(0, MathHelper.TwoPi);
                    Vector2 offset = new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle)) * rand.NextFloat(minoffset, maxoffset);
                    Vector2 particlePosition = Vector2.Lerp(position, newPosition, mu) + offset;

                    // Create the particle.
                    particleSystem.AddParticles(particlePosition, velocity, 1);
                }

                // Store any time we didn't use, so it can be part of the next update.
                timeLeftOver = timeToSpend;
            }

            position = newPosition;
        }
    }
}

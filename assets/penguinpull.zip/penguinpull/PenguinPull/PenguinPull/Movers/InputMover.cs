﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    /// <summary>
    /// This is the mover used for the boat.
    /// Takes a given Object and controls its movement using input from the Keyboard/Gamepad.
    /// The unit is not affected by the global vertical speed.
    /// </summary>
    class InputMover
    {
        #region fields
        protected const float DEFAULTMAXSPEED = 522;

        /// <summary>
        /// The unit which this mover will control
        /// </summary>
        protected Unit unit;

        protected float maxSpeed;

        /// <summary>
        /// (0 to 1)
        /// Each frame, the unit will gain the difference between the maximum speed and its current
        /// speed, multiplied by this factor. If it is 1, then the unit will always move at its
        /// maximum speed.
        /// </summary>
        protected float accelerateFactor;

        /// <summary>
        /// (0 to 1)
        /// Each frame in which no input is received, the unit will lose the difference between
        /// the maximum speed and its current speed, multiplied by this factor. If it is 1,
        /// then the unit will stop instantly.
        /// </summary>
        protected float decelerateFactor;
        #endregion

        #region Constructors & Initialization
        public InputMover(Unit unit) : this(unit, DEFAULTMAXSPEED) { }
        public InputMover(Unit unit, float maxSpeed)
        {
            this.unit = unit;
            this.maxSpeed = maxSpeed;
            this.accelerateFactor = 0.1f;
            this.decelerateFactor = 0.1f;
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Checks the input devices and updates the objects properties accordingly
        /// </summary>
        private void UpdateInputs(InputState input)
        {
//            Console.WriteLine("Position: " + unit.position);
            if (input.IsMoveUnitUp(null))
                unit.acceleration.Y = -(maxSpeed + unit.velocity.Y) * Math.Min(1, accelerateFactor); //higher Y values are lower on the screen.
            else if (input.IsMoveUnitDown(null))
                unit.acceleration.Y = (maxSpeed - unit.velocity.Y) * Math.Min(1, accelerateFactor);
            else
                unit.acceleration.Y = -(unit.velocity.Y * Math.Min(1, decelerateFactor));

            if (input.IsMoveUnitRight(null))
                unit.acceleration.X = (maxSpeed - unit.velocity.X) * Math.Min(1, accelerateFactor);
            else if (input.IsMoveUnitLeft(null))
                unit.acceleration.X = -(maxSpeed + unit.velocity.X) * Math.Min(1, accelerateFactor);
            else
                unit.acceleration.X = -(unit.velocity.X * Math.Min(1, decelerateFactor));
        }

        /// <summary>
        /// Updates the unit's position and speed
        /// </summary>
        private void Move()
        {
            unit.velocity += unit.acceleration;
            unit.position += (unit.velocity * Unit.game.TargetElapsedTime.Milliseconds / 1000.0f); // compensate for framerate
        }
        #endregion

        #region Update
        public void Update(InputState input)
        {
            UpdateInputs(input);
            Move();
        }
        #endregion
    }
}

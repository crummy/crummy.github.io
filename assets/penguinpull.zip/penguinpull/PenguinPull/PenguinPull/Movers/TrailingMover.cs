﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    /// <summary>
    /// This is the mover used for the Ice Floe.
    /// Takes two objects and moves the first object around depending on the position of the 
    /// second object.
    /// The global downward force doesn't apply if the unit is too far below the parent unit.
    /// </summary>
    class TrailingMover
    {
        #region fields
        protected const float DEFAULTDRAG = 0.1f;
        protected const float DEFAULTTETHERDISTANCE = 100;
        protected const float DEFAULTTETHERFORCE = 0.25f;


        /// <summary>
        /// The unit which this mover will control.
        /// </summary>
        protected Unit unit;

        /// <summary>
        /// The unit which is being followed.
        /// </summary>
        protected Unit parent;

        /// <summary>
        /// How far away the unit can be from the parent before it is pulled back.
        /// ie: how long the rope is.
        /// </summary>
        public float tetherLength;

        /// <summary>
        /// How far away the unit can be from the parent before it is pulled back.
        /// ie: how long the rope is.
        /// </summary>
        public Vector2 tetherOffset;

        /// <summary>
        /// (0 to 1)
        /// The higher this is, the more force will be applied when the unit leaves the tether distance.
        /// </summary>
        public float tetherForce;

        /// <summary>
        /// (0 to 1)
        /// The percentage of speed lost each frame. 0 is no drag, 1 will stop acceleration
        /// </summary>
        float drag;
        
        #endregion

        #region Constructors & Initialization
        public TrailingMover(Unit unit, Unit parent) : this(unit, parent, Vector2.Zero, DEFAULTTETHERDISTANCE) { }

        public TrailingMover(Unit unit, Unit parent, Vector2 offsetPosition) : this(unit, parent, offsetPosition, DEFAULTTETHERDISTANCE) { }

        public TrailingMover(Unit unit, Unit parent, Vector2 offsetPosition, float tetherLength)
        {
            this.unit = unit;
            this.parent = parent;
            this.tetherOffset = offsetPosition;
            this.tetherLength = tetherLength;
            this.drag = DEFAULTDRAG;
            this.tetherForce = DEFAULTTETHERFORCE;
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Updates the unit's position and speed
        /// </summary>
        private void Move()
        {
            Vector2 distanceFromParent = (parent.midPosition() - unit.midPosition());

            if (distanceFromParent.Length() > tetherLength)
                unit.acceleration = tetherForce * distanceFromParent * Unit.game.TargetElapsedTime.Milliseconds / 1000.0f;
            else
                unit.acceleration = Vector2.Zero;

            unit.acceleration += -unit.velocity * drag; //slow down due to drag


            unit.velocity += unit.acceleration;
            unit.position += (unit.velocity * Unit.game.TargetElapsedTime.Milliseconds / 1000.0f); // compensate for framerate

            if (unit.midPosition().Y <= parent.midPosition().Y + tetherLength) // The global downward force doesn't apply if the unit is too far below the parent unit
                unit.position.Y += globals.verticalSpeed;
        }

        #endregion

        #region Update
        public void Update()
        {
            Move();
        }
        #endregion
    }
}

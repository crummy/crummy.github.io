using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace PenguinPull
{
    #region Globals
    struct globals
    {
        public const bool DEBUGMODE = true;

        public const int MSecPerSec = 1000;

        public const int screenWidth = 1024;
        public const int screenHeight = 768;
        public const int gameplayLeftEdge = 12; // Gameplay bounds
        public const int gameplayRightEdge = 876;
        public const int gameplayTopEdge = 54;
        public const int gameplayBottomEdge = 756;
        public const int gameWidth = gameplayRightEdge - gameplayLeftEdge;
        public const int gameHeight = gameplayBottomEdge - gameplayTopEdge;
        public static readonly Rectangle gameBounds = new Rectangle(gameplayLeftEdge, gameplayTopEdge, gameWidth, gameHeight);
        public const int spawnPosition = -240;

        public static float cloudHeight = 75;
        public const float cloudTransparency = 0.89f;
        public const float cloudShadowTransparency = 0.4f;

        public static float verticalSpeed = 3.5f; // rate at which everything is moving downward in pixels per frame

        // how many milliseconds to wait before hiding the cursor due to inactivity
        public static float reticleHideTime = 4000;

        // In Seconds - How long the boat will be invulnerable after colliding with an obstacle.
        public static float InvulnerableTimeAfterCollision = 2.0f;

        public static float volume;
        public static bool isMusicOn;

        public static GameTime timeSinceLastUpdate;

        public const float tempHeatingFactor = 2f; // Rate at which icefloe heats in the sun

        public const int haltTime = 500; // ms to briefly pause the game upon certain events

        #region LayerDepth
        // The following values are the ranges for the layer depths of units.
        public const float water_drawLayer = 0.0f;
        public const float underwater_bottomDrawLayer = 0.01f;
        public const float underwater_topDrawLayer = 0.25f;
        public const float penguinPowerup_drawLayer = 0.251f;
        public const float rocketPowerup_drawLayer = 0.251f;
        public const float onwater_bottomDrawLayer = 0.26f;
        public const float onwater_topDrawLayer = 0.50f;
        public const float rope_drawLayer = 0.5005f;
        public const float penguin_drawLayer = 0.501f;
        public const float rocket_drawLayer = 0.502f;
        public const float cloudshadow_bottomDrawLayer = 0.51f;
        public const float cloudshadow_topDrawLayer = 0.75f;
        public const float cloud_bottomDrawLayer = 0.76f;
        public const float cloud_topDrawLayer = 0.90f;

        public const float reticle_drawLayer = 0.9901f;
        public const float HUD_drawLayer = 0.991f;
        public const float HUDelement_drawLayer = 0.992f;
        public const float HUDfilling_drawLayer = 0.993f;
        public const float HUDthermometer_drawLayer = 0.994f;
        public const float HUDrocket_drawLayer = 0.995f;
        #endregion

        #region Difficulty
        //See curvemanager.cs and difficultymanager.cs for usage
        #region Clouds
        public const double cloud_diffBaseInput_min = -0.6;
        public const double cloud_diffBaseTotal_min = 1200.0;
        public const double cloud_diffMultInput_min = 0.002;
        public const double cloud_diffMultResult_min = 800.0;

        public const double cloud_diffBaseInput_max = 0.0;
        public const double cloud_diffBaseTotal_max = 3000.0;
        public const double cloud_diffMultInput_max = 0.002;
        public const double cloud_diffMultResult_max = 5000.0;
        #endregion

        #region Icebergs
        public const double iceberg_diffBaseInput_min = 0.4;
        public const double iceberg_diffBaseTotal_min = 600.0;
        public const double iceberg_diffMultInput_min = 0.001;
        public const double iceberg_diffMultResult_min = 200.0;

        public const double iceberg_diffBaseInput_max = 0.4;
        public const double iceberg_diffBaseTotal_max = 2200.0;
        public const double iceberg_diffMultInput_max = 0.001;
        public const double iceberg_diffMultResult_max = 800.0;
        #endregion

        #region Penguins
        public const double penguin_diffBaseInput_min = 0.0;
        public const double penguin_diffBaseTotal_min = 3000.0;
        public const double penguin_diffMultInput_min = 0.001;
        public const double penguin_diffMultResult_min = 12000.0;

        public const double penguin_diffBaseInput_max = 0.0;
        public const double penguin_diffBaseTotal_max = 6000.0;
        public const double penguin_diffMultInput_max = 0.001;
        public const double penguin_diffMultResult_max = 20000.0;
        #endregion

        
        
        #region Rockets
        public const double rocket_diffBaseInput_min = 0.0;
        public const double rocket_diffBaseTotal_min = 13000.0;
        public const double rocket_diffMultInput_min = 0.001;
        public const double rocket_diffMultResult_min = 7000.0;

        public const double rocket_diffBaseInput_max = 0.0;
        public const double rocket_diffBaseTotal_max = 19000.0;
        public const double rocket_diffMultInput_max = 0.001;
        public const double rocket_diffMultResult_max = 7000.0;
        
        public const int windFrequency = 20000; // in ms. 
        public static float windMaxSpeed = .75f;
        #endregion
        #endregion
    }
    #endregion

    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {

        #region Fields
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        ScreenManager screenManager;
        #endregion

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferWidth = globals.screenWidth;
            graphics.PreferredBackBufferHeight = globals.screenHeight;

            screenManager = new ScreenManager(this);
            Components.Add(screenManager);

            screenManager.AddScreen(new Logo(), null);

            globals.isMusicOn = Settings.Default.Music;
            globals.volume = Settings.Default.Sound;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        protected override void Update(GameTime gameTime)
        {
            globals.timeSinceLastUpdate = gameTime;
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.Black);

            // The real drawing happens inside the screen manager component.
            base.Draw(gameTime);
        }
    }
}

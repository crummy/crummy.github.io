﻿namespace PenguinPull
{
    partial class DebugInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GeneratorTabPage = new System.Windows.Forms.TabPage();
            this.GeneratorTextBox = new System.Windows.Forms.TextBox();
            this.InfoTabControl = new System.Windows.Forms.TabControl();
            this.UpdateFreqLabel = new System.Windows.Forms.Label();
            this.UpdateFreqUpDown = new System.Windows.Forms.NumericUpDown();
            this.UpdateFreqLabel2 = new System.Windows.Forms.Label();
            this.UpdateFreqPanel = new System.Windows.Forms.Panel();
            this.UnitTabPage = new System.Windows.Forms.TabPage();
            this.UnitTextBox = new System.Windows.Forms.TextBox();
            this.GeneratorTabPage.SuspendLayout();
            this.InfoTabControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UpdateFreqUpDown)).BeginInit();
            this.UpdateFreqPanel.SuspendLayout();
            this.UnitTabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // GeneratorTabPage
            // 
            this.GeneratorTabPage.Controls.Add(this.GeneratorTextBox);
            this.GeneratorTabPage.Location = new System.Drawing.Point(4, 22);
            this.GeneratorTabPage.Name = "GeneratorTabPage";
            this.GeneratorTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.GeneratorTabPage.Size = new System.Drawing.Size(236, 336);
            this.GeneratorTabPage.TabIndex = 0;
            this.GeneratorTabPage.Text = "Generators";
            this.GeneratorTabPage.UseVisualStyleBackColor = true;
            // 
            // GeneratorTextBox
            // 
            this.GeneratorTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.GeneratorTextBox.BackColor = System.Drawing.Color.Black;
            this.GeneratorTextBox.ForeColor = System.Drawing.Color.Gold;
            this.GeneratorTextBox.Location = new System.Drawing.Point(7, 7);
            this.GeneratorTextBox.Multiline = true;
            this.GeneratorTextBox.Name = "GeneratorTextBox";
            this.GeneratorTextBox.ReadOnly = true;
            this.GeneratorTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.GeneratorTextBox.Size = new System.Drawing.Size(221, 268);
            this.GeneratorTextBox.TabIndex = 0;
            // 
            // InfoTabControl
            // 
            this.InfoTabControl.Controls.Add(this.GeneratorTabPage);
            this.InfoTabControl.Controls.Add(this.UnitTabPage);
            this.InfoTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.InfoTabControl.Location = new System.Drawing.Point(0, 0);
            this.InfoTabControl.Name = "InfoTabControl";
            this.InfoTabControl.SelectedIndex = 0;
            this.InfoTabControl.Size = new System.Drawing.Size(244, 362);
            this.InfoTabControl.TabIndex = 0;
            this.InfoTabControl.SelectedIndexChanged += new System.EventHandler(this.InfoTabControl_SelectedIndexChanged);
            // 
            // UpdateFreqLabel
            // 
            this.UpdateFreqLabel.AutoSize = true;
            this.UpdateFreqLabel.Location = new System.Drawing.Point(9, 10);
            this.UpdateFreqLabel.Name = "UpdateFreqLabel";
            this.UpdateFreqLabel.Size = new System.Drawing.Size(133, 13);
            this.UpdateFreqLabel.TabIndex = 1;
            this.UpdateFreqLabel.Text = "Debug Update Frequency:";
            // 
            // UpdateFreqUpDown
            // 
            this.UpdateFreqUpDown.Location = new System.Drawing.Point(12, 26);
            this.UpdateFreqUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.UpdateFreqUpDown.Name = "UpdateFreqUpDown";
            this.UpdateFreqUpDown.Size = new System.Drawing.Size(78, 20);
            this.UpdateFreqUpDown.TabIndex = 2;
            this.UpdateFreqUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.UpdateFreqUpDown.ValueChanged += new System.EventHandler(this.UpdateFreqUpDown_ValueChanged);
            // 
            // UpdateFreqLabel2
            // 
            this.UpdateFreqLabel2.AutoSize = true;
            this.UpdateFreqLabel2.Location = new System.Drawing.Point(96, 28);
            this.UpdateFreqLabel2.Name = "UpdateFreqLabel2";
            this.UpdateFreqLabel2.Size = new System.Drawing.Size(47, 13);
            this.UpdateFreqLabel2.TabIndex = 3;
            this.UpdateFreqLabel2.Text = "seconds";
            // 
            // UpdateFreqPanel
            // 
            this.UpdateFreqPanel.Controls.Add(this.UpdateFreqLabel);
            this.UpdateFreqPanel.Controls.Add(this.UpdateFreqLabel2);
            this.UpdateFreqPanel.Controls.Add(this.UpdateFreqUpDown);
            this.UpdateFreqPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.UpdateFreqPanel.Location = new System.Drawing.Point(0, 303);
            this.UpdateFreqPanel.Name = "UpdateFreqPanel";
            this.UpdateFreqPanel.Size = new System.Drawing.Size(244, 59);
            this.UpdateFreqPanel.TabIndex = 4;
            // 
            // UnitTabPage
            // 
            this.UnitTabPage.Controls.Add(this.UnitTextBox);
            this.UnitTabPage.Location = new System.Drawing.Point(4, 22);
            this.UnitTabPage.Name = "UnitTabPage";
            this.UnitTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.UnitTabPage.Size = new System.Drawing.Size(236, 236);
            this.UnitTabPage.TabIndex = 1;
            this.UnitTabPage.Text = "Units";
            this.UnitTabPage.UseVisualStyleBackColor = true;
            // 
            // UnitTextBox
            // 
            this.UnitTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.UnitTextBox.BackColor = System.Drawing.Color.Black;
            this.UnitTextBox.ForeColor = System.Drawing.Color.Gold;
            this.UnitTextBox.Location = new System.Drawing.Point(7, 7);
            this.UnitTextBox.Multiline = true;
            this.UnitTextBox.Name = "UnitTextBox";
            this.UnitTextBox.ReadOnly = true;
            this.UnitTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.UnitTextBox.Size = new System.Drawing.Size(221, 168);
            this.UnitTextBox.TabIndex = 1;
            // 
            // DebugInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(244, 362);
            this.Controls.Add(this.UpdateFreqPanel);
            this.Controls.Add(this.InfoTabControl);
            this.MinimumSize = new System.Drawing.Size(260, 300);
            this.Name = "DebugInfo";
            this.Text = "DebugInfo";
            this.GeneratorTabPage.ResumeLayout(false);
            this.GeneratorTabPage.PerformLayout();
            this.InfoTabControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.UpdateFreqUpDown)).EndInit();
            this.UpdateFreqPanel.ResumeLayout(false);
            this.UpdateFreqPanel.PerformLayout();
            this.UnitTabPage.ResumeLayout(false);
            this.UnitTabPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage GeneratorTabPage;
        private System.Windows.Forms.TextBox GeneratorTextBox;
        private System.Windows.Forms.TabControl InfoTabControl;
        private System.Windows.Forms.Label UpdateFreqLabel;
        private System.Windows.Forms.NumericUpDown UpdateFreqUpDown;
        private System.Windows.Forms.Label UpdateFreqLabel2;
        private System.Windows.Forms.Panel UpdateFreqPanel;
        private System.Windows.Forms.TabPage UnitTabPage;
        private System.Windows.Forms.TextBox UnitTextBox;
    }
}
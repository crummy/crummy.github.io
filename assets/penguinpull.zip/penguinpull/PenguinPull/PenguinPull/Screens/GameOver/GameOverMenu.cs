﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    class GameOverMenu : MenuScreen
    {

        #region Initialization

        public GameOverMenu()
            : base("Game Over")
        {
            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);

            // Create menu items
            MenuItem retryMenuItem = new MenuItem("Retry");
            MenuItem cloudSeedingMenuItem = new MenuItem("Cloud Seeding");
            MenuItem quitMenuItem = new MenuItem("Quit to menu");

            // Connect menu items to handlers
            retryMenuItem.Selected += RetrySelected;
            cloudSeedingMenuItem.Selected += seedingSelected;
            quitMenuItem.Selected += QuitSelected;

            // Add items to menu
            menuItems.Add(retryMenuItem);
            menuItems.Add(cloudSeedingMenuItem);
            menuItems.Add(quitMenuItem);

            position = new Vector2(512, 490);   // start location of menu items

        }

        #endregion

        #region Handle Input

        /// <summary>
        /// On cancel, get rid of pause screen and return to game
        /// </summary>
        protected override void OnCancel()
        {
           // ScreenManager.RemoveScreen(this);
        }

        /// <summary>
        /// Helper overload makes it easy to use OnCancel as a MenuEntry event handler.
        /// </summary>
        protected void OnCancel(object sender, EventArgs e)
        {
            OnCancel();
        }

        /// <summary>
        /// Event handler for retry
        /// </summary>
        void RetrySelected(object sender, EventArgs e)
        {
            foreach (GameScreen screen in ScreenManager.GetScreens())
            {
                ScreenManager.RemoveScreen(screen);
            }
            ScreenManager.AddScreen(new InGame(), null);
        }

        void seedingSelected(object sender, EventArgs e)
        {
            ScreenManager.AddScreen(new CloudSeeding(), null);
        }

        /// <summary>
        /// Event handler for returning to game
        /// </summary>
        void QuitSelected(object sender, EventArgs e)
        {
            foreach (GameScreen screen in ScreenManager.GetScreens())
            {
                ScreenManager.RemoveScreen(screen);
            }
            ScreenManager.AddScreen(new MenuBackground(), null);
            ScreenManager.AddScreen(new MainMenu(), null);
            ScreenManager.playMenuSong();
        }

        #endregion

    }
}

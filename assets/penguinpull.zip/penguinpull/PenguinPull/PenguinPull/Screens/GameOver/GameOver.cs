﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    class GameOver : GameScreen
    {
        #region Fields
        Texture2D texture;
        string reason; // reason why they got a game over
        #endregion

        #region Initialization

        public GameOver(string reason)
        {
            IsPopup = true;

            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);

            this.reason = reason;
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content;
            texture = content.Load<Texture2D>("menu/gameover");
        }

        #endregion

        #region Handle Input
        public override void HandleInput(InputState input)
        {
            ScreenManager.RemoveScreen(this);
        }
        #endregion

        #region Draws
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            spriteBatch.Begin();
            spriteBatch.Draw(texture, new Vector2(512 - texture.Width / 2, 365 - texture.Height / 2), Color.White);
            spriteBatch.DrawString(ScreenManager.Font, reason, new Vector2(526 - texture.Width / 2, 390), Color.Red);
            spriteBatch.End();

            base.Draw(gameTime);
        }
        #endregion

        #region Update
        public override void Update(GameTime gameTime, bool otherScreenHasFocus, bool coveredByOtherScreen)
        {
            // overridden to ensure screen gets drawn
        }
        #endregion
    }
}

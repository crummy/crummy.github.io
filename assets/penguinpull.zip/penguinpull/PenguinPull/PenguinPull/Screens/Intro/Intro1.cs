﻿using System;
using System.Collections.Generic;
using System.Linq; 
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace PenguinPull
{
    /// <summary>
    /// First screen of the intro, with wide panning shot of ice floes
    /// </summary>
    class Intro1 : GameScreen
    {

        #region Fields
        Texture2D texture;
        Vector2 textureLocation = new Vector2(0,40);
        SoundEffect beep;
        SpriteFont introFont;
        String text = "IN A.D. 199X,\nICE MELT WAS\nBEGINNING.";
        Vector2 textLocation = new Vector2(75, 350);
        int msSinceStarted = 0;
        int msSinceLastFrame = 0;
        int msSinceLastLetter = 0;
        int msPerLetter = 50;
        int msPerFrame = 500;
        int currentLetterCount = 0;
        int frames = 1;
        int currentFrame = 0;
        int width = 1200;
        int height = 232;
        #endregion

        #region Initialization

        public Intro1()
        {
            TransitionOnTime = TimeSpan.FromSeconds(0.5);
            TransitionOffTime = TimeSpan.FromSeconds(0.5);
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content;
            beep = content.Load<SoundEffect>(@"intro/sounds/beep");
            texture = content.Load<Texture2D>(@"intro/textures/intro1");
            introFont = content.Load<SpriteFont>(@"intro/M04");
            
            ScreenManager.playMenuSong();
        }

        #endregion

        #region Handle Input

        public override void HandleInput(InputState input)
        {
            PlayerIndex playerIndex;
            if (input.IsMenuSelect(null, out playerIndex) || input.IsMenuCancel(null, out playerIndex))
            {
                ScreenManager.RemoveScreen(this);
                ScreenManager.AddScreen(new Intro2(), null);
            }
        }

        #endregion

        #region Update and Draw
        public override void Update(GameTime gameTime, bool otherScreenHasFocus,
                                                       bool coveredByOtherScreen)
        {
            base.Update(gameTime, otherScreenHasFocus, false);

            // if time is up for this menu screen, or if the user hit a key, advance to next screen
            msSinceStarted += gameTime.ElapsedGameTime.Milliseconds;
            if (msSinceStarted > 5000)
            {
                ScreenManager.RemoveScreen(this);
                ScreenManager.AddScreen(new Intro2(), null);
            }

            // animate image if necessary
            msSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;
            if (msSinceLastFrame > msPerFrame)
            {
                msSinceLastFrame -= msPerFrame;
                currentFrame++;
                if (currentFrame > frames)
                {
                    currentFrame = 0;
                }
            }

            // tap out text
            msSinceLastLetter += gameTime.ElapsedGameTime.Milliseconds;
            if ((msSinceLastLetter > msPerLetter)
                && (currentLetterCount < text.Length))
            {
                msSinceLastLetter -= msPerLetter;
                currentLetterCount++;
                beep.Play(globals.volume, 0, 0);
            }

            // slowly shift panorama to the left
            textureLocation.X = textureLocation.X - (float)gameTime.ElapsedGameTime.TotalMilliseconds / 50;
        }

        /// <summary>
        /// Draws the background screen.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            Viewport viewport = ScreenManager.GraphicsDevice.Viewport;
            Rectangle fullscreen = new Rectangle(0, 0, viewport.Width, viewport.Height);

            spriteBatch.Begin();

            // draw image
            spriteBatch.Draw(texture,
                textureLocation,
                new Rectangle(0,
                    height * currentFrame,
                    width, height),
                Color.White, 0, Vector2.Zero, 1, SpriteEffects.None, 0);

            // draw text shadow
            spriteBatch.DrawString(introFont,
                text.Substring(0, currentLetterCount),
                new Vector2(textLocation.X + 4, textLocation.Y + 4), Color.Gray);
            // draw text
            spriteBatch.DrawString(introFont,
                text.Substring(0, currentLetterCount),
                textLocation, Color.White);

            spriteBatch.End();
        }
        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio; 

namespace PenguinPull
{
    /// <summary>
    /// Third screen of intro; bobbing tug boat
    /// </summary>
    class Intro3 : GameScreen
    {

        #region Fields
        Texture2D texture;
        Vector2 textureLocation = new Vector2(150, 300);
        Texture2D puff;
        Vector2 puffLocation = new Vector2(550, 275);
        float puffOpacity = 1;
        SoundEffect beep;
        SpriteFont introFont;
        String text = "ONLY YOU CAN\nSAVE THE\nPENGUINS!";
        Vector2 textLocation = new Vector2(50, 50);
        int msSinceStarted = 0;
        int msSinceLastFrame = 0;
        int msSinceLastLetter = 0;
        int msPerLetter = 50;
        int msPerFrame = 500;
        int currentLetterCount = 0;
        int frames = 1;
        int currentFrame = 0;
        int width = 724;
        int height = 400;
        #endregion

        #region Initialization

        public Intro3()
        {
            TransitionOnTime = TimeSpan.FromSeconds(0.5);
            TransitionOffTime = TimeSpan.FromSeconds(0.5);
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content;
            beep = content.Load<SoundEffect>(@"intro/sounds/beep");
            puff = content.Load<Texture2D>(@"intro/textures/puff");
            texture = content.Load<Texture2D>(@"intro/textures/intro3");
            introFont = content.Load<SpriteFont>(@"intro/M04");
        }

        #endregion

        #region Handle Input

        public override void HandleInput(InputState input)
        {
            PlayerIndex playerIndex;
            if (input.IsMenuSelect(null, out playerIndex) || input.IsMenuCancel(null, out playerIndex))
            {
                ScreenManager.RemoveScreen(this);
                ScreenManager.AddScreen(new MenuBackground(), null);
                ScreenManager.AddScreen(new MainMenu(), null);
            }
        }

        #endregion

        #region Update and Draw
        public override void Update(GameTime gameTime, bool otherScreenHasFocus,
                                                       bool coveredByOtherScreen)
        {
            base.Update(gameTime, otherScreenHasFocus, false);

            // if time is up for this menu screen, or if the user hit a key, advance to next screen
            msSinceStarted += gameTime.ElapsedGameTime.Milliseconds;
            if (msSinceStarted > 5000)
            {
                ScreenManager.RemoveScreen(this);
                ScreenManager.AddScreen(new MenuBackground(), null);
                ScreenManager.AddScreen(new MainMenu(), null);
            }

            // animate image if necessary
            msSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;
            if (msSinceLastFrame > msPerFrame)
            {
                msSinceLastFrame -= msPerFrame;
                currentFrame++;
                if (currentFrame > frames)
                {
                    currentFrame = 0;
                }
            }

            // tap out text
            msSinceLastLetter += gameTime.ElapsedGameTime.Milliseconds;
            if ((msSinceLastLetter > msPerLetter)
                && (currentLetterCount < text.Length))
            {
                msSinceLastLetter -= msPerLetter;
                currentLetterCount++;
                beep.Play(globals.volume, 0, 0);
            }

            // move puff to right
            puffLocation.X = puffLocation.X + (float)gameTime.ElapsedGameTime.TotalMilliseconds / 10;
            puffOpacity = puffOpacity - 1 / (5 * (float)gameTime.ElapsedGameTime.TotalMilliseconds);
            if (puffLocation.X > 700)
            {
                puffLocation.X = 550;
                puffOpacity = 1;
            }
        }

        /// <summary>
        /// Draws the background screen.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            Viewport viewport = ScreenManager.GraphicsDevice.Viewport;
            Rectangle fullscreen = new Rectangle(0, 0, viewport.Width, viewport.Height);

            spriteBatch.Begin();

            // draw image
            spriteBatch.Draw(texture,
                textureLocation,
                new Rectangle(0,
                    height * currentFrame,
                    width, height),
                Color.White, 0, Vector2.Zero, 1, SpriteEffects.None, 0);

            // smoke puffs
            spriteBatch.Draw(puff,
                puffLocation,
                Color.White * puffOpacity);

            // draw text shadow
            spriteBatch.DrawString(introFont,
                text.Substring(0, currentLetterCount),
                new Vector2(textLocation.X + 4, textLocation.Y + 4), Color.Gray);
            // draw text
            spriteBatch.DrawString(introFont,
                text.Substring(0, currentLetterCount),
                textLocation, Color.White);

            spriteBatch.End();
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework; 
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace PenguinPull
{
    class Logo : GameScreen
    {
        #region Fields
        Texture2D logo;
        float fade = 0;
        int msSinceStarted = 0;
        SoundEffect woosh;
        
        #endregion 

        #region Initialization
        public Logo()
        {
            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content; 
            logo = content.Load<Texture2D>(@"intro/textures/mediocre");
            woosh = content.Load<SoundEffect>("megasound");
            woosh.Play(globals.volume, 0f, 0f);
            

        }

        #endregion

        #region Handle Input

        public override void HandleInput(InputState input)
        {
            PlayerIndex playerIndex;
            if (input.IsMenuSelect(null, out playerIndex) || input.IsMenuCancel(null, out playerIndex))
            {
                ScreenManager.RemoveScreen(this);
                woosh.Dispose();
                ScreenManager.AddScreen(new Intro1(), null);
            }
        }
        #endregion

        #region Update and Draw
        public override void Update(GameTime gameTime, bool otherScreenHasFocus,
                                                       bool coveredByOtherScreen)
        {
            base.Update(gameTime, otherScreenHasFocus, false);

            // if time is up for this menu screen, or if the user hit a key, advance to next screen
            msSinceStarted += gameTime.ElapsedGameTime.Milliseconds;
            if (msSinceStarted < 1000)
            {
                fade = fade + (float)(gameTime.ElapsedGameTime.Milliseconds * .001);
            } else if (msSinceStarted > 4000) {
                fade = fade - (float)(gameTime.ElapsedGameTime.Milliseconds * .001);
            }
            if (msSinceStarted > 5000)
            {
                ScreenManager.RemoveScreen(this);
                ScreenManager.AddScreen(new Intro1(), null);
            }

        }

        /// <summary>
        /// Draws the background screen.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            Viewport viewport = ScreenManager.GraphicsDevice.Viewport;

            spriteBatch.Begin();

            // draw image
            spriteBatch.Draw(logo,
                Vector2.Zero,
                Color.White * fade);
            spriteBatch.End();
        }
        #endregion
    }
}

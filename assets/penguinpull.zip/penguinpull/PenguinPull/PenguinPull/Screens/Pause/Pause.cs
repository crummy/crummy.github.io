﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    class Pause : GameScreen
    {
        #region Fields
        Texture2D texture;
        #endregion

        #region Initialization

        public Pause()
        {
            IsPopup = true;

            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content;
            texture = content.Load<Texture2D>("menu/pause");
        }

        #endregion

        #region Handle Input
        public override void HandleInput(InputState input)
        {
            ScreenManager.RemoveScreen(this);
        }
        #endregion

        #region Draws
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            spriteBatch.Begin();
            spriteBatch.Draw(texture, new Vector2(512 - texture.Width / 2, 465 - texture.Height / 2), Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }
        #endregion

        #region Update
        public override void Update(GameTime gameTime, bool otherScreenHasFocus, bool coveredByOtherScreen)
        {
            // overridden to ensure screen gets drawn
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Media;

namespace PenguinPull
{
    class PauseMenu : MenuScreen
    {
        public event EventHandler<EventArgs> returnToGame;

        #region Initialization

        public PauseMenu() : base("Pause")
        {
            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);

            // Create menu items
            MenuItem optionsMenuItem = new MenuItem("Options");
            MenuItem retryMenuItem = new MenuItem("Retry");
            MenuItem quitMenuItem = new MenuItem("Quit to menu");
            MenuItem backMenuItem = new MenuItem("Back");

            // Connect menu items to handlers
            optionsMenuItem.Selected += OptionsSelected;
            retryMenuItem.Selected += RetrySelected;
            quitMenuItem.Selected += QuitSelected;
            backMenuItem.Selected += BackSelected;

            // Add items to menu
            menuItems.Add(optionsMenuItem);
            menuItems.Add(retryMenuItem);
            menuItems.Add(quitMenuItem);
            menuItems.Add(backMenuItem);
        }

        #endregion

        #region Handle Input

        /// <summary>
        /// On cancel, get rid of pause screen and return to game
        /// </summary>
        protected override void OnCancel()
        {
            returnToGame(this, new EventArgs());
            ScreenManager.RemoveScreen(this);
        }

        /// <summary>
        /// Helper overload makes it easy to use OnCancel as a MenuEntry event handler.
        /// </summary>
        protected void OnCancel(object sender, EventArgs e)
        {
            OnCancel();
        }

        /// <summary>
        /// Event handler for options
        /// </summary>
        void OptionsSelected(object sender, EventArgs e)
        {
            ScreenManager.AddScreen(new OptionsMenu(), null);
        }

        /// <summary>
        /// Event handler for retry
        /// </summary>
        void RetrySelected(object sender, EventArgs e)
        {
            foreach (GameScreen screen in ScreenManager.GetScreens())
            {
                ScreenManager.RemoveScreen(screen);
            }
            ScreenManager.AddScreen(new InGame(), null);
        }

        /// <summary>
        /// Event handler for returning to game
        /// </summary>
        void BackSelected(object sender, EventArgs e)
        {
            returnToGame(this, new EventArgs());
            ScreenManager.RemoveScreen(this);
        }

        /// <summary>
        /// Event handler for returning to game
        /// </summary>
        void QuitSelected(object sender, EventArgs e)
        {
            foreach (GameScreen screen in ScreenManager.GetScreens())
            {
                ScreenManager.RemoveScreen(screen);
            }
            ScreenManager.AddScreen(new MenuBackground(), null);
            ScreenManager.AddScreen(new MainMenu(), null);
            ScreenManager.playMenuSong();
        }

        #endregion

    }
}

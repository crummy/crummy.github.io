﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace PenguinPull
{
    class InGame : GameScreen
    {
        #region Const Fields

        const int MAX_FIRED_ROCKETS = 20;

        const int waterAnimSpeed = 200;
        const int waterFrames = 3; // How many animation frames we have for water
        const int waterWidth = 72; // Size of each frame
        const int waterHeight = 72;
        const int scoreSize = 8; // Digits used to display score

        const uint big_freq = 5;
        const uint small_freq = 10;
        const uint snow_freq = 1;
        #endregion

        #region Fields
        int slow = 0;

        #region Textures
        Texture2D water;
        Texture2D blank;
        Texture2D thermometer;
        Texture2D thermometerEmpty;
        Texture2D thermometerFilling;
        Texture2D rocketIcon;
        #endregion

        #region SoundFX
        SoundEffect crash;
        SoundEffect penguinPickupSound;
        SoundEffectInstance penguinsFull;
        SoundEffect penguinsFullSound;
        SoundEffect rocketPickup;
        #endregion

        #region Variables and Bools
        float waterVertPos = 0; // Current Y position of water textures
        int timeSinceLastWaterFrame = 0; // Counter to keep track of fps for water frames
        int currentFrame = 0; // Keeps track of current frame for water

        private  int invulnerableFrames = 0; // How much longer the boat and icefloe are immune to collisions

        private bool didCollideWithCloud = false;

        private int msSinceGameOver = 0;
        private bool gameOverScreenAppeared = false;
        private string gameOverReason;
        private bool isGameOver = false;
        private bool isGamePaused = false;

        private int haltMs;
        private int msSinceHalt = 0;
        private int msSinceWind = 0; // set this to be greater than globals.windFrequency;

        // should these be here?
        int score = 0;
        int hiScore;
        int rocketCount = 3;
        int rocketMax = 9;

        //temp gauge floats
        float CurrTemplocy = 575;
        float BaseTemplocy = 575;
        float CurrTemplocx = 895;
        int tick = 0;
        #endregion

        #region Strings
        string scoreString = "";
        string hiScoreString = "";
        #endregion

        #region Player Objects
        TugBoat boat;
        Rope rope;
        InputMover boatMover;
        Reticle reticle;
//        Rocket rocket;
        List<Rocket> firedRockets;
        IceFloe icefloe;
        TrailingMover icefloeMover;
        #endregion

        #region Generators
        internal List<IUnitList> UnitListList;
        internal CloudListGenerator cloudList;
        internal IcebergListGenerator icebergList;
        internal PenguinListGenerator penguinList;
        internal RocketListGenerator rocketList;
        internal WhaleListGenerator whaleList;
        #endregion

        #region Difficulty Managers
        List<DifficultyManager> DMList;
        DifficultyManager DMCloud;
        DifficultyManager DMIceberg;
        DifficultyManager DMPenguin;
        DifficultyManager DMRocket;
        #endregion

        #region HUD Rectangles
        // user interface rectangles
        // Wait, since when can memory be dynamically allocated outside of a class function?
        // This smells bad. Should allocate the memory inside of the constructor.
        Rectangle topUI = new Rectangle(0, 0, globals.screenWidth, globals.gameplayTopEdge);
        Rectangle rightUI = new Rectangle(globals.gameplayRightEdge, globals.gameplayTopEdge, globals.screenWidth - globals.gameplayRightEdge, globals.screenHeight - globals.gameplayTopEdge);
        Rectangle leftUI = new Rectangle(0, globals.gameplayTopEdge, globals.gameplayLeftEdge, globals.screenHeight - globals.gameplayTopEdge);
        Rectangle bottomUI = new Rectangle(globals.gameplayLeftEdge, globals.gameplayBottomEdge, globals.screenWidth - globals.gameplayLeftEdge, globals.screenHeight - globals.gameplayBottomEdge);
        #endregion

        #region Debug
        DebugInfo debug;
        #endregion

        #endregion

        #region Initialization

        public InGame()
        {
            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);

            boat = new TugBoat(((globals.gameplayRightEdge - globals.gameplayLeftEdge) / 2) + globals.gameplayLeftEdge
                                - (TugBoat.FRAMEWIDTH / 2),
                                ((globals.gameplayBottomEdge - globals.gameplayTopEdge) / 2) + globals.gameplayTopEdge);
            rope = new Rope(120);
            boatMover = new InputMover(boat, 200);
            reticle = new Reticle();
            //rocket = new Rocket();
            firedRockets = new List<Rocket>();
            icefloe = new IceFloe((int)boat.position.X, (int)boat.position.Y + 100);
            icefloe.gameOver += gameOver;
            icefloe.haltGame += haltGame;
            icefloeMover = new TrailingMover(icefloe, boat, TugBoat.tetherOffset, rope.length);
            // icefloe will trail behind the boat based on the length of the rope

            hiScore = Settings.Default.hiScore;

            Initialize_Generators();
            Initialize_Difficulty();

            if (globals.DEBUGMODE)
            {
                debug = new DebugInfo(this);
                debug.Show();
            }
        }

        public override void LoadContent()
        {
            ScreenManager.playGameSong();
            Unit.Initialize(ScreenManager.Game, ScreenManager.SpriteBatch);
            boat.Initialize();
            reticle.Initialize();
            icefloe.Initialize();
            rope.Initialize();

            boat.midPosition(globals.gameplayLeftEdge + globals.gameWidth / 2, globals.gameplayTopEdge + globals.gameHeight * .75f);
            icefloe.midPosition(boat.midPosition().X, boat.midPosition().Y + rope.length);

            ContentManager content = ScreenManager.Game.Content;
            water = content.Load<Texture2D>("game/textures/water");
            blank = content.Load<Texture2D>("blank");
            thermometer = content.Load<Texture2D>("interface/textures/thermometer");
            thermometerEmpty = content.Load<Texture2D>("interface/textures/thermometer_empty");
            thermometerFilling = content.Load<Texture2D>("interface/textures/thermometer_filling");
            rocketIcon = content.Load<Texture2D>("game/units/tugboat/rocket");
            crash = content.Load<SoundEffect>("game/collision");
            penguinPickupSound = content.Load<SoundEffect>("game/units/duck-quack4");
            rocketPickup = content.Load<SoundEffect>("game/units/rocketpickup");
            penguinsFullSound = content.Load<SoundEffect>("game/units/penguinsfull");
            penguinsFull = penguinsFullSound.CreateInstance();

            
        }

        /// <summary>
        /// Allocates and initializes the generators,
        /// then adds each of them to UnitListList.
        /// TODO: Get rid of those magic numbers!
        /// </summary>
        private void Initialize_Generators()
        {
            UnitListList = new List<IUnitList>();
            RandomPlus random = new RandomPlus();
            // Set up cloudList
            cloudList = new CloudListGenerator(random, true, 800, 4000, globals.spawnPosition, globals.gameplayLeftEdge,
                                                globals.gameplayRightEdge, new Vector2(0, globals.verticalSpeed),
                                                new Vector2(0, globals.verticalSpeed), Vector2.Zero, Vector2.Zero,
                                                big_freq, small_freq, snow_freq);
            UnitListList.Add(cloudList);
            // Set up icebergList
            icebergList = new IcebergListGenerator(random, true, 500, 2000, globals.spawnPosition, globals.gameplayLeftEdge,
                                                globals.gameplayRightEdge, new Vector2(0, globals.verticalSpeed),
                                                new Vector2(0, globals.verticalSpeed), Vector2.Zero, Vector2.Zero);
            UnitListList.Add(icebergList);
            // Set up penguinList
            penguinList = new PenguinListGenerator(random, true, 1500, 7000, globals.spawnPosition, globals.gameplayLeftEdge,
                                                globals.gameplayRightEdge, new Vector2(0, globals.verticalSpeed),
                                                new Vector2(0, globals.verticalSpeed), Vector2.Zero, Vector2.Zero);
            UnitListList.Add(penguinList);
            // Set up rocketList
            rocketList = new RocketListGenerator(random, true, 1500, 7000, globals.spawnPosition, globals.gameplayLeftEdge,
                                                globals.gameplayRightEdge, new Vector2(0, globals.verticalSpeed),
                                                new Vector2(0, globals.verticalSpeed), Vector2.Zero, Vector2.Zero);
            UnitListList.Add(rocketList);

            whaleList = new WhaleListGenerator(random, true, 10000, 20000, globals.spawnPosition, globals.gameplayLeftEdge,
                                             globals.gameplayRightEdge, new Vector2(0, globals.verticalSpeed),
                                             new Vector2(0, globals.verticalSpeed), Vector2.Zero, Vector2.Zero);
            UnitListList.Add(whaleList);
        }

        /// <summary>
        /// Allocates and initializes the difficulty managers,
        /// then adds each of them to DMList.
        /// NOTE: Current values 0.0 are stubs. Do not use function yet.
        /// </summary>
        private void Initialize_Difficulty()
        {
            DMList = new List<DifficultyManager>();
            // Create two temp curvemanagers for readability.
            CurveManager MinCurve;
            CurveManager MaxCurve;
            // Set up the cloud difficulty manager.
            MinCurve = new CurveManager(true, globals.cloud_diffMultResult_min, globals.cloud_diffBaseInput_min,
                                        globals.cloud_diffMultInput_min, globals.cloud_diffBaseTotal_min);
            MaxCurve = new CurveManager(true, globals.cloud_diffMultResult_max, globals.cloud_diffBaseInput_max,
                                        globals.cloud_diffMultInput_max, globals.cloud_diffBaseTotal_max);
            DMCloud = new DifficultyManager(cloudList, MinCurve, MaxCurve);
            DMList.Add(DMCloud);
            // Set up the iceberg difficulty manager.
            MinCurve = new CurveManager(false, globals.iceberg_diffMultResult_min, globals.iceberg_diffBaseInput_min,
                                        globals.iceberg_diffMultInput_min, globals.iceberg_diffBaseTotal_min);
            MaxCurve = new CurveManager(false, globals.iceberg_diffMultResult_max, globals.iceberg_diffBaseInput_max,
                                        globals.iceberg_diffMultInput_max, globals.iceberg_diffBaseTotal_max);
            DMIceberg = new DifficultyManager(icebergList, MinCurve, MaxCurve);
            DMList.Add(DMIceberg);
            // Set up the penguin difficulty manager.
            MinCurve = new CurveManager(true, globals.penguin_diffMultResult_min, globals.penguin_diffBaseInput_min,
                                        globals.penguin_diffMultInput_min, globals.penguin_diffBaseTotal_min);
            MaxCurve = new CurveManager(true, globals.penguin_diffMultResult_max, globals.penguin_diffBaseInput_max,
                                        globals.penguin_diffMultInput_max, globals.penguin_diffBaseTotal_max);
            DMPenguin = new DifficultyManager(penguinList, MinCurve, MaxCurve);
            DMList.Add(DMPenguin);
            // Set up the rocket difficulty manager.
            MinCurve = new CurveManager(true, globals.rocket_diffMultResult_min, globals.rocket_diffBaseInput_min,
                                        globals.rocket_diffMultInput_min, globals.rocket_diffBaseTotal_min);
            MaxCurve = new CurveManager(true, globals.rocket_diffMultResult_max, globals.rocket_diffBaseInput_max,
                                        globals.rocket_diffMultInput_max, globals.rocket_diffBaseTotal_max);
            DMRocket = new DifficultyManager(rocketList, MinCurve, MaxCurve);
            DMList.Add(DMRocket);
        }

        #endregion

        #region Handle Input

        /// <summary>
        /// Responds to user input, changing the selected entry and accepting
        /// or cancelling the menu.
        /// </summary>
        public override void HandleInput(InputState input)
        {
            if (isGameOver || isGameHalted())
            {
                boatMover.Update(new InputState());
                return;
            }
            if (input.IsPauseGame(null))
            {
                isGamePaused = true;
                PauseMenu pauseMenu = new PauseMenu();
                pauseMenu.returnToGame += unpause;

                ScreenManager.AddScreen(new Pause(), null);
                ScreenManager.AddScreen(pauseMenu, null);
            }
            boatMover.Update(input);
            reticle.Update(input);
            if (input.IsFireRocket(null) &&
                globals.gameBounds.Contains(input.CurrentMouseStates[0].X, input.CurrentMouseStates[0].Y) &&
                rocketCount > 0 ) // If the user clicks inside the game bounds, fire a rocket to the cursor
            {
                rocketCount--;
                firedRockets.Add(new Rocket(boat.getRocketLaunchPosition(), new Vector2(input.CurrentMouseStates[0].X, input.CurrentMouseStates[0].Y)));
                firedRockets.Last().Initialize();
                firedRockets.Last().Exploded += rocketExploded;
            }
            // If the user presses space, fire a rocket straight up and collide with the first cloud it hits
            if (input.IsFireRocketStraightUp(null) && rocketCount > 0)
            {
                rocketCount--;
                firedRockets.Add(new Rocket(boat.getRocketLaunchPosition(), new Vector2(boat.midPosition().X, 0)));
                firedRockets.Last().Initialize();
                firedRockets.Last().Exploded += rocketExploded;
                firedRockets.Last().collidesWithClouds = true;
            }
        }

        #endregion

        #region Event Handlers

        void rocketExploded(object sender, EventArgs e)
        {
            // need to initialize clouds or compiler will complain 
            Cloud oldCloud = null;
            CloudListGenerator.CloudType type = CloudListGenerator.CloudType.Small;
            bool replace = false;

            foreach (Cloud cloud in cloudList)
            {
                if (cloud.getBoundingBox().Contains(new Point((int)((Rocket)sender).endPosition.X, (int)((Rocket)sender).endPosition.Y)))
                {
                    oldCloud = cloud;
                    replace = true;
                    if (oldCloud is SmallCloud)
                        type = CloudListGenerator.CloudType.Big;
                    else if (oldCloud is BigCloud)
                        type = CloudListGenerator.CloudType.Snow;
                    else
                        replace = false; // If we shoot a rocket at a snow cloud it will ignore it and make a new small cloud
                }
            }
            if (replace)
            {
                //new cloud will have same mid position as old cloud
                cloudList.SpawnCloudAt(new Vector2(oldCloud.position.X, oldCloud.position.Y), type);
                cloudList.Remove(oldCloud);
            }
            else
            {
                cloudList.SpawnCloudAt(((Rocket)sender).endPosition, CloudListGenerator.CloudType.Small);
            }
        }

        void gameOver(object sender, gameoverEventArgs e)
        {
            isGameOver = true;
            gameOverReason = e.reason;
            msSinceGameOver = 0;
            boat.velocity = new Vector2(0, 1);
            Settings.Default.hiScore = hiScore;
            Settings.Default.Save();
            if (globals.DEBUGMODE)
                debug.Hide();
        }

        void unpause(object sender, EventArgs e)
        {
            isGamePaused = false;
        }

        void haltGame(object sender, EventArgs e)
        {
            haltGame(500);
        }

        #endregion

        #region Update

        //NOTE: Are we using otherScreenHasFocus and coveredByOtherScreen?
        public override void Update(GameTime gameTime, bool otherScreenHasFocus, bool coveredByOtherScreen)
        {
            if (isGamePaused)
                return;
            if (isGameHalted(gameTime))
            {
                icefloe.UpdateWhileHalted(gameTime);
                UpdatePlayer(gameTime);
                return;
            }
            if (isGameOver)
            {
                boat.position += new Vector2(0, globals.verticalSpeed);
                msSinceGameOver += gameTime.ElapsedGameTime.Milliseconds;
                if (msSinceGameOver > 1000 && !gameOverScreenAppeared)
                {
                    ScreenManager.AddScreen(new GameOver(gameOverReason), null);
                    ScreenManager.AddScreen(new GameOverMenu(), null);
                    gameOverScreenAppeared = true;
                }
            }

            AnimateWater(gameTime.ElapsedGameTime.Milliseconds);
            if (!isGameOver)
            {
                GenerateScore();
                ChangeTemp();
            }
            UpdateUnits(gameTime);
            UpdatePlayer(gameTime);
            UpdateGenerators(gameTime);
            GenerateWind(gameTime);
            UpdateInvuln();

            if (globals.DEBUGMODE)
                debug.Update(gameTime);
        }
        #endregion

        #region Misc Updates
        /// <summary>
        /// Animates the water and moves it down.
        /// </summary>
        /// <param name="timeElapsed">Game time elapsed in milliseconds.</param>
        protected void AnimateWater(int timeElapsed)
        {
            // animate the water
            timeSinceLastWaterFrame += timeElapsed;
            if (timeSinceLastWaterFrame > waterAnimSpeed)
            {
                timeSinceLastWaterFrame = 0;
                currentFrame++;
                if (currentFrame == waterFrames)
                {
                    currentFrame = 0;
                }
            }

            // move water down
            waterVertPos += globals.verticalSpeed;
            if (waterVertPos > waterHeight)
                waterVertPos = 0;
        }

        /// <summary>
        /// Updates the score and the string displaying it.
        /// </summary>
        protected void GenerateScore()
        {

            //for testing score
            slow++;
            if (slow == 25 && isGameOver == false)
            {
                score = score + 1 * (icefloe.penguinCount);
                slow = 0;
            }

            scoreString = score.ToString();
            while (scoreString.Length < scoreSize) // add leading zeroes
                scoreString = "0" + scoreString;
            scoreString = "SCORE " + scoreString;
            if (score > hiScore)
                hiScore = score;
            hiScoreString = hiScore.ToString();
            while (hiScoreString.Length < scoreSize) // same here
                hiScoreString = "0" + hiScoreString;
            hiScoreString = "HI " + hiScoreString;
        }

        /// <summary>
        /// Calls Update for each unit,
        /// then does collision checking.
        /// </summary>
        protected void UpdateUnits(GameTime gameTime)
        {
            if (!isGameOver)
                didCollideWithBounds(boat); // ensure boat stays in bounds of map

            tick++;
            foreach (Cloud cloud in cloudList)
            {
                cloud.Update(gameTime); // update cloud
                if (cloud.position.Y - cloud.height() > globals.gameplayBottomEdge) // check that cloud hasn't left gameplay bounds
                    cloud.isAlive = false; // if so, set it to dead
            }

            foreach (Iceberg iceberg in icebergList)
            {
                //Test offscreen icebergs to make sure they wont cover anything
                if (iceberg.position.Y < -iceberg.Texture.Height)
                {
                    ResolveSpawnCollisions(iceberg);
                }
                iceberg.Update(gameTime);
                if (invulnerableFrames <= 0 && (didCollide(icefloe, iceberg) || didCollide(boat, iceberg)))
                {
                    if (isGameOver) break;
                    haltGame(1000); // Pause the game for a second
                    crash.Play(globals.volume, 0f, 0f); // Play a crash sound
                    invulnerableFrames = (int)(globals.InvulnerableTimeAfterCollision * ScreenManager.FPS()); // Make the player invulnerable briefly
                    Vector2 awayFromObstacle = new Vector2(boat.position.X - iceberg.position.X, boat.position.Y - iceberg.position.Y);
                    awayFromObstacle.Normalize();
                    boat.velocity += Iceberg.pushForce * awayFromObstacle; // push boat away from iceburg a little bit
                    icefloe.losePenguin();
                }
                if (iceberg.position.Y - iceberg.height() > globals.gameplayBottomEdge) // check that cloud hasn't left gameplay bounds
                    iceberg.isAlive = false; // if so, set it to dead
            }
            foreach (Whale whale in whaleList)
            {
                //Test offscreen icebergs to make sure they wont cover anything
                if (whale.position.Y < -whale.Texture.Height)
                {
                    ResolveSpawnCollisions(whale);
                }
                whale.Update(gameTime);
                if (invulnerableFrames <= 0 && (didCollide(icefloe, whale) || didCollide(boat, whale)))
                {
                    if (isGameOver) break;
                    haltGame(1000); // Pause the game for a second
                    crash.Play(globals.volume, 0f, 0f); // Play a crash sound
                    invulnerableFrames = (int)(globals.InvulnerableTimeAfterCollision * ScreenManager.FPS()); // Make the player invulnerable briefly
                    Vector2 awayFromObstacle = new Vector2(boat.position.X - whale.position.X, boat.position.Y - whale.position.Y);
                    awayFromObstacle.Normalize();
                    boat.velocity += Iceberg.pushForce * awayFromObstacle; // push boat away from iceburg a little bit
                    icefloe.losePenguin();
                }
                if (whale.position.Y - whale.height() > globals.gameplayBottomEdge) // check that cloud hasn't left gameplay bounds
                    whale.isAlive = false; // if so, set it to dead
            }

            foreach (RocketPowerup rocketPowerup in rocketList)
            {
                rocketPowerup.Update(gameTime);
                if (didCollide(boat, rocketPowerup) || didCollide(icefloe, rocketPowerup))
                {
                    if (rocketCount < rocketMax)
                    {
                        rocketPickup.Play();
                        rocketCount++;
                        rocketPowerup.isAlive = false;
                    }
                }
                if (rocketPowerup.position.Y - rocketPowerup.height() > globals.gameplayBottomEdge)
                    rocketPowerup.isAlive = false;
            }

            foreach (PenguinPowerup penguin in penguinList)
            {
                if (didCollide(boat, penguin) || didCollide(icefloe, penguin))
                {
                    if (icefloe.gainPenguin())
                    {
                        penguin.isAlive = false;
                        penguinPickupSound.Play(globals.volume, 0f, 0f);
                    }
                    else
                    {
                        penguinsFull.Play();
                    }
                }
                penguin.Update(gameTime);
                if (penguin.position.Y - penguin.height() > globals.gameplayBottomEdge)
                    penguin.isAlive = false;
            }

            foreach (Rocket rocket in firedRockets)
            {
                rocket.Update(gameTime);
                if (!rocket.hasExploded && rocket.isAlive && rocket.collidesWithClouds)
                {
                    foreach (Cloud cloud in cloudList)
                    {
                        if (!(cloud is SnowCloud) && didCollide(rocket, cloud))
                        {
                            rocket.rocketInMotionInstance.Stop();
                            rocket.rocketExploded.Play(globals.volume, 0f, 0f);
                            rocket.endPosition = cloud.midPosition();
                            rocket.hasExploded = true;
                            rocketExploded(rocket, new EventArgs());
                            break;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Make sure the obstacle isn't preventing the player form getting
        /// anything good.
        /// </summary>
        /// <param name="obstacle">The obstacle to do collision checking on.</param>
        protected void ResolveSpawnCollisions(Obstacle obstacle)
        {
            foreach (Cloud cloud in cloudList)
            {
                if (didCollide(obstacle, cloud) || didCollideShadow(obstacle, cloud))
                    obstacle.position.Y -= obstacle.Texture.Height;
            }
            foreach (PenguinPowerup penguin in penguinList)
            {
                if (didCollide(obstacle, penguin))
                    obstacle.position.Y -= obstacle.Texture.Height;
            }
            foreach (RocketPowerup rocket in rocketList)
            {
                if (didCollide(obstacle, rocket))
                    obstacle.position.Y -= obstacle.Texture.Height;
            }
            if (obstacle is Whale)
            {
                foreach (Iceberg iceberg in icebergList)
                {
                    if (didCollide(obstacle, iceberg))
                        obstacle.position.Y -= obstacle.Texture.Height;
                }
            }
        }

        /// <summary>
        /// Updates the generators and the difficulty managers.
        /// </summary>
        /// <param name="gameTime">You know what time it is.</param>
        protected void UpdateGenerators(GameTime gameTime)
        {
            foreach (IUnitList UL in UnitListList)
                UL.Update(gameTime);
            foreach (DifficultyManager dm in DMList)
                dm.Update(gameTime);
        }

        /// <summary>
        /// Calls update for boat, icefloe, and icefloemover.
        /// </summary>
        protected void UpdatePlayer(GameTime gameTime)
        {
            boat.Update(gameTime);
            icefloe.Update(gameTime, boat);
            icefloeMover.Update();
        }

        /// <summary>
        /// Temperature gauge update
        /// </summary>
        //600 = 0 Degrees
        //575 = 25 Degrees (start pos)
        //350 = 50 Degrees
        //45 = 100 Degrees
        protected void ChangeTemp()
        {
            //tick slows gauge by fps
            //adjust "on" for size of tick
            tick++;
            didCollideWithCloud = false;
            if (tick > 30)
            {
                foreach (Cloud cloud in cloudList)
                {
                    //cools temp if in shade (collision a bit wonky right now)
                    if (didCollideShadow(icefloe, cloud))
                    {
                        icefloe.underCloud(cloud);
                        didCollideWithCloud = true;
                        break;
                    }
                }
                if (!didCollideWithCloud)
                    icefloe.notUnderCloud();

                // currentTemp is between 0 and 100.
                CurrTemplocy = BaseTemplocy - icefloe.currentTemp * 5 - 45;
                tick = 0;

                if (icefloe.currentTemp >= IceFloe.maxTemp)
                    // shrink icefloe
                    tick = 0;
                else if (icefloe.currentTemp <= IceFloe.minTemp)
                    // grow icefloe
                    tick = 0;
            }
        }

        /// <summary>
        /// Decrement invulnerability time, draw boat transparent if invulnerable.
        /// </summary>
        private void UpdateInvuln()
        {
            invulnerableFrames--;
            // if boat is invulnerable, draw it half transparent
            if (invulnerableFrames > 0)
            {
                boat.alpha = 0.5f;
                icefloe.alpha = 0.5f;
                rope.alpha = 0.5f;
            }
            else
            {
                boat.alpha = 1.0f;
                icefloe.alpha = 1.0f;
                rope.alpha = 1.0f;
            }
        }

        private void GenerateWind(GameTime gameTime)
        {
            msSinceWind += gameTime.ElapsedGameTime.Milliseconds;
            if (msSinceWind > globals.windFrequency)
            {
                RandomPlus rnd = new RandomPlus();
                Cloud.wind = new Vector2(rnd.NextFloat(-1, 1), rnd.Next(-1, 1));
                Cloud.wind = Vector2.Multiply(Cloud.wind, globals.windMaxSpeed);
                msSinceWind = 0;
            }
        }
        #endregion

        #region Halt game (brief pause)
        public bool isGameHalted()
        {
            if (msSinceHalt < haltMs)
            {
                return true;
            }
            else
                return false;
        }
        public bool isGameHalted(GameTime gameTime)
        {
            msSinceHalt += gameTime.ElapsedGameTime.Milliseconds;
            if (msSinceHalt < haltMs)
                return true;
            else
                return false;
        }
        public void haltGame(int ms)
        {
            msSinceHalt = 0;
            haltMs = ms;
        }
        #endregion

        #region Collision Functions
        /// <summary>
        /// Checks for collision between two units
        /// </summary>
        /// <param name="first">First unit to check</param>
        /// <param name="second">Second unit to check</param>
        /// <returns>True if they collided</returns>
        public bool didCollide(Unit first, Unit second)
        {
            if (!first.isAlive || !second.isAlive)
                return false;
            Rectangle firstBB = first.getBoundingBox();
            Rectangle secondBB = second.getBoundingBox();
            if (firstBB.Top > secondBB.Bottom)
                return false;
            else if (firstBB.Bottom < secondBB.Top)
                return false;
            else if (firstBB.Left > secondBB.Right)
                return false;
            else if (firstBB.Right < secondBB.Left)
                return false;
            return true;
        }
        /// <summary>
        /// Checks for collision between a unit and a Cloud's shadow
        /// </summary>
        /// <param name="first">First unit to check</param>
        /// <param name="second">Cloud who's shadow is to be checked</param>
        /// <returns>True if the unit collides with the shadow</returns>
        public bool didCollideShadow(Unit first, Cloud second)
        {
            if (!first.isAlive || !second.isAlive)
                return false;
            Rectangle firstBB = first.getBoundingBox();
            Rectangle secondBB = second.getShadowBoundingBox();
            if (firstBB.Top > secondBB.Bottom)
                return false;
            else if (firstBB.Bottom < secondBB.Top)
                return false;
            else if (firstBB.Left > secondBB.Right)
                return false;
            else if (firstBB.Right < secondBB.Left)
                return false;
            return true;
        }

        /// <summary>
        /// Checks for collision with unit and bounds of gameplay area
        /// </summary>
        /// <param name="unit">Unit to check for collision</param>
        /// <returns>True if it collided</returns>
        private bool didCollideWithBounds(Unit unit)
        {
            if (unit.position.X < globals.gameplayLeftEdge)
                unit.position.X = globals.gameplayLeftEdge;
            if (unit.position.X + unit.width() > globals.gameplayRightEdge)
                unit.position.X = globals.gameplayRightEdge - unit.width();
            if (unit.position.Y < globals.gameplayTopEdge)
                unit.position.Y = globals.gameplayTopEdge;
            if (unit.position.Y + unit.height() > globals.gameplayBottomEdge)
                unit.position.Y = globals.gameplayBottomEdge - unit.height();
            return true;
        }
        #endregion

        #region Draws
        /// <summary>
        /// Draws the game.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            SpriteFont font = ScreenManager.Font;

            spriteBatch.Begin(SpriteSortMode.FrontToBack, BlendState.AlphaBlend);

            DrawBG(spriteBatch);
            DrawUnits(spriteBatch);
            DrawHUD(spriteBatch, font);

            spriteBatch.End();
        }

        private void DrawBG(SpriteBatch spriteBatch)
        {
            // draw bg
            // draws enough rows of water to fill the entire screen, plus two more (one for rounding, one for animation)
            for (int i = -waterHeight; i < globals.screenHeight / waterHeight + 2; ++i)
            {
                // draws enough columns of water to fill entire screen, plus one more (for rounding)
                for (int j = 0; j < globals.screenWidth / waterWidth + 1; ++j)
                {
                    spriteBatch.Draw(water, new Vector2(j * waterWidth, i * waterHeight + waterVertPos),
                        new Rectangle(waterWidth * currentFrame, 0, waterWidth, waterHeight), Color.White,
                        0f, Vector2.Zero, 1f, SpriteEffects.None, globals.water_drawLayer);
                }
            }
        }

        private void DrawUnits(SpriteBatch spriteBatch)
        {
            // draw obstacles
            foreach (Iceberg iceberg in icebergList)
                iceberg.Draw();
            foreach (Whale whale in whaleList)
            {
                whale.Draw();
                //spriteBatch.Draw(blank, whale.getBoundingBox(), Color.Orange * 0.5f); // draws bounding boxes
            }

            // draw rocket powers
            foreach (RocketPowerup rocketPowerup in rocketList)
                rocketPowerup.Draw();

            // draw boat
            if (boat.isAlive)
                boat.Draw();

            icefloe.Draw();
            //spriteBatch.Draw(blank, icefloe.getBoundingBox(), Color.Orange * 0.5f); // draws bounding boxes

            // draw rope
            rope.Draw(boat.midPosition() + TugBoat.tetherOffset,
                icefloe.midPosition() + IceFloe.tetherOffset);

            // draw penguins
            foreach (PenguinPowerup penguin in penguinList)
                penguin.Draw();

            // draw clouds
            foreach (Cloud cloud in cloudList)
            {
                cloud.Draw();
                // draws bounding boxes:
                // spriteBatch.Draw(blank, cloud.getBoundingBox(), null, Color.Orange * 0.5f, 0, Vector2.Zero, SpriteEffects.None, globals.cloudshadow_topDrawLayer);
                // draws mid position:
                // spriteBatch.Draw(blank, cloud.midPosition(), Color.Red);
            }

            reticle.Draw();
            foreach (Rocket rocket in firedRockets)
            {
                if (rocket.isAlive)
                    rocket.Draw();
            }
        }

        private void DrawHUD(SpriteBatch spriteBatch, SpriteFont font)
        {
            // draw black interface around edges of screen
            spriteBatch.Draw(blank, topUI, null, Color.Black, 0f, Vector2.Zero, SpriteEffects.None, globals.HUD_drawLayer);
            spriteBatch.Draw(blank, rightUI, null, Color.Black, 0f, Vector2.Zero, SpriteEffects.None, globals.HUD_drawLayer);
            spriteBatch.Draw(blank, bottomUI, null, Color.Black, 0f, Vector2.Zero, SpriteEffects.None, globals.HUD_drawLayer);
            spriteBatch.Draw(blank, leftUI, null, Color.Black, 0f, Vector2.Zero, SpriteEffects.None, globals.HUD_drawLayer);

            // draw scores
            spriteBatch.DrawString(ScreenManager.Font,
                scoreString, new Vector2(20, 10), Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, globals.HUDelement_drawLayer);
            spriteBatch.DrawString(ScreenManager.Font,
                hiScoreString, new Vector2(650, 10), Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, globals.HUDelement_drawLayer);

            // draw thermometer
            spriteBatch.Draw(thermometerEmpty, new Vector2(CurrTemplocx, 41), null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, globals.HUDelement_drawLayer);
            spriteBatch.Draw(thermometerFilling, new Vector2(CurrTemplocx, CurrTemplocy), null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, globals.HUDfilling_drawLayer); // the red stuff - this gets adjusted
            spriteBatch.Draw(thermometer, new Vector2(CurrTemplocx, 41), null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, globals.HUDthermometer_drawLayer);

            // draw rocket counter
            if (rocketCount > 3)
            {
                spriteBatch.Draw(rocketIcon, new Vector2(895, 700), null, Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, globals.HUDrocket_drawLayer);
                spriteBatch.DrawString(font, "x" + rocketCount, new Vector2(940, 720), Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, globals.HUDrocket_drawLayer);
            }
            else
            {
                for (int i = 0; i < rocketCount; ++i)
                    spriteBatch.Draw(rocketIcon, new Vector2(895 + (rocketIcon.Width + 8) * i, 700), null, Color.White, 0.0f, Vector2.Zero, 1f, SpriteEffects.None, globals.HUDrocket_drawLayer);
            }
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;

namespace PenguinPull
{
    class Tutorial : GameScreen
    {
        #region Fields
        Texture2D tutorial;
        float fade = 0;
        int msSinceStarted = 0;
        int msSinceEnded = 0;
        Song ocean;
        #endregion

        #region Initialization
        public Tutorial()
        {
            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content;
            tutorial = content.Load<Texture2D>(@"game/tutorial");
            ocean = content.Load<Song>("ocean-wave-1");
            if(globals.isMusicOn == true)
            MediaPlayer.Play(ocean);
        }

        #endregion

        #region Handle Input

        public override void HandleInput(InputState input)
        {
            PlayerIndex playerIndex;
            if (input.IsMenuSelect(null, out playerIndex) || input.IsMenuCancel(null, out playerIndex))
            {
                msSinceEnded = 1000;
            }
        }
        #endregion

        #region Update and Draw
        public override void Update(GameTime gameTime, bool otherScreenHasFocus,
                                                       bool coveredByOtherScreen)
        {
            base.Update(gameTime, otherScreenHasFocus, false);

            msSinceStarted += gameTime.ElapsedGameTime.Milliseconds;
            // if the user hit a key, fade out then advance to next screen
            if (msSinceEnded < 0) {
                ScreenManager.RemoveScreen(this);
                MediaPlayer.Pause();
                ScreenManager.AddScreen(new InGame(), null);
            }
            else if (msSinceStarted < 1000)
            {
                fade = fade + (float)(gameTime.ElapsedGameTime.Milliseconds * .001);
            }
            else if (msSinceEnded > 0 || msSinceStarted > 30000)
            {
                fade = fade - (float)(gameTime.ElapsedGameTime.Milliseconds * .001);
                msSinceEnded -= gameTime.ElapsedGameTime.Milliseconds;
            }
        }

        /// <summary>
        /// Draws the background screen.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            Viewport viewport = ScreenManager.GraphicsDevice.Viewport;

            spriteBatch.Begin();

            // draw image
            spriteBatch.Draw(tutorial,
                Vector2.Zero,
                Color.White * fade);
            spriteBatch.End();
        }
        #endregion
    }
}

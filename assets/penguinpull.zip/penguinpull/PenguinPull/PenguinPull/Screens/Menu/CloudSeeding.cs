﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace PenguinPull
{
    class CloudSeeding : GameScreen
    {
        #region Fields
        Texture2D seeding;
        float fade = 0;
        int msSinceStarted = 0;

        #endregion

        #region Initialization
        public CloudSeeding()
        {
            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content;
            seeding = content.Load<Texture2D>(@"menu/textures/cloudseeding");


        }

        #endregion

        #region Handle Input

        public override void HandleInput(InputState input)
        {
            PlayerIndex playerIndex;
            if (input.IsMenuSelect(null, out playerIndex) || input.IsMenuCancel(null, out playerIndex))
            {
                ScreenManager.RemoveScreen(this);

            }
        }
        #endregion

        #region Update and Draw
        public override void Update(GameTime gameTime, bool otherScreenHasFocus,
                                                       bool coveredByOtherScreen)
        {
            base.Update(gameTime, otherScreenHasFocus, false);

            // if time is up for this menu screen, or if the user hit a key, advance to next screen
            msSinceStarted += gameTime.ElapsedGameTime.Milliseconds;
            if (msSinceStarted < 1000)
            {
                fade = fade + (float)(gameTime.ElapsedGameTime.Milliseconds * .001);
            }
            else if (msSinceStarted > 1920000)
            {
                fade = fade - (float)(gameTime.ElapsedGameTime.Milliseconds * .001);
            }
            if (msSinceStarted > 2000000)
            {
                ScreenManager.RemoveScreen(this);

            }

        }

        /// <summary>
        /// Draws the background screen.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            Viewport viewport = ScreenManager.GraphicsDevice.Viewport;

            spriteBatch.Begin();

            // draw image
            spriteBatch.Draw(seeding,
                Vector2.Zero,
                Color.White * fade);
            spriteBatch.End();
        }
        #endregion
    }
}

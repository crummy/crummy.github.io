﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;

namespace PenguinPull
{

    class OptionsMenu : MenuScreen
    {
        #region Fields
        MenuItem musicMenuItem, soundMenuItem, backMenuItem;
        #endregion

        #region Initialization

        public OptionsMenu() : base("Options")
        {
            IsPopup = false;

            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);

            // Create menu items
            if (globals.isMusicOn)
                musicMenuItem = new MenuItem("Music: On");
            else
                musicMenuItem = new MenuItem("Music: Off");
            if (globals.volume == 0)
                soundMenuItem = new MenuItem("Sound: Off");
            else
                soundMenuItem = new MenuItem("Sound: On");
            backMenuItem = new MenuItem("Back");

            // Connect menu items to handlers
            musicMenuItem.Selected += MusicSelected;
            soundMenuItem.Selected += SoundSelected;
            backMenuItem.Selected += BackSelected;

            // Add items to menu
            menuItems.Add(musicMenuItem);
            menuItems.Add(soundMenuItem);
            menuItems.Add(backMenuItem);
        }

        #endregion

        #region Handle Input

        /// <summary>
        /// Handler for when the user has cancelled the menu.
        /// </summary>
        protected override void OnCancel()
        {
            ScreenManager.RemoveScreen(this);
        }

        /// <summary>
        /// Helper overload makes it easy to use OnCancel as a MenuEntry event handler.
        /// </summary>
        protected void OnCancel(object sender, EventArgs e)
        {
            OnCancel();
        }

        /// <summary>
        /// Event handler for music
        /// </summary>
        void MusicSelected(object sender, EventArgs e)
        {
            musicMenuItem.Text = (globals.isMusicOn ? "Music: Off" : "Music: On");

            if (globals.isMusicOn)
                ScreenManager.turnMusicOff();
            else
                ScreenManager.turnMusicOn();
        }

        /// <summary>
        /// Event handler for sound
        /// </summary>
        void SoundSelected(object sender, EventArgs e)
        {
            soundMenuItem.Text = ((globals.volume == 0) ? "Sound: On" : "Sound: Off");

            if (globals.volume == 0)
                ScreenManager.turnSoundOn();
            else
                ScreenManager.turnSoundOff();
        }

        /// <summary>
        /// Event handler leaving options menu
        /// </summary>
        void BackSelected(object sender, EventArgs e)
        {
            OnCancel();
        }

        #endregion

    }
}

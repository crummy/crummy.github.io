﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace PenguinPull
{

    class Title : GameScreen
    {

        #region Fields
        Texture2D texture;
        #endregion

        #region Initialization

        public Title()
        {
            TransitionOnTime = TimeSpan.FromSeconds(0.5);
            TransitionOffTime = TimeSpan.FromSeconds(0.5);
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content;
            texture = content.Load<Texture2D>(@"menu/textures/logo");
        }

        #endregion

        #region Draws
        /// <summary>
        /// Draws the background screen.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            //Viewport viewport = ScreenManager.GraphicsDevice.Viewport;
            //Rectangle fullscreen = new Rectangle(0, 0, viewport.Width, viewport.Height);

            spriteBatch.Begin();

            // draw image
            spriteBatch.Draw(texture,
                new Vector2(512,200),
                null, Color.White, 0f, new Vector2(texture.Width/2, texture.Height/2), 0f, SpriteEffects.None, .5f);
            spriteBatch.End();
        }
        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;

namespace PenguinPull
{
    
    class MenuBackground : GameScreen
    {

        #region Fields
        Texture2D texture;
        Texture2D titleTexture;
        Vector2 titlePosition;
        int msSinceStart = 0;
        #endregion

        #region Initialization

        public MenuBackground()
        {
            TransitionOnTime = TimeSpan.FromSeconds(0.5);
            TransitionOffTime = TimeSpan.FromSeconds(0.5);
            titlePosition.Y = -400;
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content;
            texture = content.Load<Texture2D>(@"menu/textures/menubg");
            titleTexture = content.Load<Texture2D>(@"menu/textures/logo");
        }

        #endregion

        #region Draws and Updates

        /// <summary>
        /// Updates the menu.
        /// </summary>
        public override void Update(GameTime gameTime, bool otherScreenHasFocus,
                                                       bool coveredByOtherScreen)
        {
            msSinceStart += gameTime.ElapsedGameTime.Milliseconds;

            titlePosition.X = 512 - titleTexture.Width/2;
            if (titlePosition.Y < 0)
                titlePosition.Y = titlePosition.Y + msSinceStart / 20;
        }

        /// <summary>
        /// Draws the background screen.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            SpriteFont font = ScreenManager.Font;

            spriteBatch.Begin();

            // draw bg
            spriteBatch.Draw(texture,
                Vector2.Zero,
                Color.White);
            // draw title
            spriteBatch.Draw(titleTexture,
                titlePosition,
                Color.White);

            spriteBatch.End();
        }
        #endregion

    }
}

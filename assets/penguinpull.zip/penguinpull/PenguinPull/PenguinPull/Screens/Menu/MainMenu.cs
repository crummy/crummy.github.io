﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PenguinPull
{
    class MainMenu : MenuScreen
    {
        #region Initalization
        public MainMenu() : base("Main Menu")
        {
            TransitionOnTime = TimeSpan.FromSeconds(0);
            TransitionOffTime = TimeSpan.FromSeconds(0);

            // Create menu items
            MenuItem startGameMenuItem = new MenuItem("Start Game");
            MenuItem optionsMenuItem = new MenuItem("Options");
            MenuItem cloudSeedingMenuItem = new MenuItem("Cloud Seeding");
            MenuItem creditsMenuItem = new MenuItem("Credits");
            MenuItem exitMenuItem = new MenuItem("Exit");

            // Connect menu items to handlers
            startGameMenuItem.Selected += startGameSelected;
            optionsMenuItem.Selected += optionsSelected;
            cloudSeedingMenuItem.Selected += seedingSelected;
            creditsMenuItem.Selected += creditsSelected;
            exitMenuItem.Selected += exitSelected;

            // Add items to menu
            menuItems.Add(startGameMenuItem);
            menuItems.Add(optionsMenuItem);
            menuItems.Add(creditsMenuItem);
            menuItems.Add(cloudSeedingMenuItem);
            menuItems.Add(exitMenuItem);
        }
        #endregion

        #region Handle Input

        /// <summary>
        /// Event handler for starting game
        /// </summary>
        void startGameSelected(object sender, EventArgs e)
        {
            foreach (GameScreen screen in ScreenManager.GetScreens())
            {
                ScreenManager.RemoveScreen(screen);
            }
            ScreenManager.AddScreen(new Tutorial(), null);
        }

        /// <summary>
        /// Event handler for entering options menu
        /// </summary>
        void optionsSelected(object sender, EventArgs e)
        {
            ScreenManager.AddScreen(new OptionsMenu(), null);
        }

        /// <summary>
        /// Event handler for viewing credits
        /// </summary>
        void creditsSelected(object sender, EventArgs e)
        {
            ScreenManager.AddScreen(new Credits(), null);
        }

        /// <summary>
        /// Event handler for viewing credits
        /// </summary>
        void seedingSelected(object sender, EventArgs e)
        {
            ScreenManager.AddScreen(new CloudSeeding(), null);
        }

        /// <summary>
        /// Event handler for quitting game
        /// </summary>
        void exitSelected(object sender, EventArgs e)
        {
            ScreenManager.Game.Exit();
        }

        /// <summary>
        /// If the user presses ESC, etc, just reset the menu (select top option)
        /// </summary>
        protected override void OnCancel()
        {
            selectedEntry = 0;
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace PenguinPull
{
    class Credits : GameScreen
    {
        #region Fields
        Texture2D black, penguin, teardrop;
        string creditsText;
        Vector2 position;
        Vector2 textSize;
        #endregion


        #region Initialization

        public Credits()
        {
            TransitionOnTime = TimeSpan.FromSeconds(0.5);
            TransitionOffTime = TimeSpan.FromSeconds(0.5);
            IsPopup = false;

            creditsText = "DEVELOPMENT\n"
                        + "-----------\n"
                        + "Michael Olson\n"
                        + "Malcolm Crum\n"
                        + "John Hurley\n"
                        + "Adam Wardell\n"
                        + "\n\n\n"
                        + "MENTOR\n"
                        + "------\n"
                        + "Arnav Jhala\n"
                        + "\n\n\n"
                        + "Cloud Seeding Info\n"
                        + "-----\n"
                        + "Wikipedia\n"
                        + "en.wikipedia.org/wiki\n"
                        +"/Cloud_seeding\n"
                        + "MUSIC\n"
                        + "-----\n"
                        + "\"Chiptune Raiders\"\n"
                        + "by Kommisar\n"
                        + "8bc.org/members/\n"
                        + " Kommisar/\n\n"
                        + "\"I Pilot Whales\"\n"
                        + "by Color a Dinosaur\n"
                        + "8bc.org/members/\n"
                        + " Color+a+Dinosaur/\n";
                        

            position.X = 20;
            position.Y = globals.screenHeight;
        }

        public override void LoadContent()
        {
            ContentManager content = ScreenManager.Game.Content;
            black = content.Load<Texture2D>("blank");
            penguin = content.Load<Texture2D>("intro/textures/intro2");
            teardrop = content.Load<Texture2D>("intro/textures/teardrop");

            textSize = ScreenManager.Font.MeasureString(creditsText);
        }

        #endregion

        #region Handle Input

        /// <summary>
        /// Responds to user input, changing the selected entry and accepting
        /// or cancelling the menu.
        /// </summary>
        public override void HandleInput(InputState input)
        {
            PlayerIndex playerIndex;
            if (input.IsPauseGame(null) || input.IsMenuSelect(null, out playerIndex))
            {
                ScreenManager.RemoveScreen(this);
            }
        }

        #endregion

        #region Draws and Updates

        /// <summary>
        /// Draws the game.
        /// </summary>
        public override void Draw(GameTime gameTime)
        {
            SpriteBatch spriteBatch = ScreenManager.SpriteBatch;
            SpriteFont font = ScreenManager.Font;

            spriteBatch.Begin();

            // draw bg
            spriteBatch.Draw(black, Vector2.Zero, null, Color.Black, 0f, Vector2.Zero, new Vector2(1024, 768), SpriteEffects.None, 0f);

            // draw credits
            spriteBatch.DrawString(font, creditsText,
                position,
                Color.White);

            // draw penguin
            spriteBatch.Draw(penguin,
                new Vector2(750, 100),
                Color.White);

            // draw teardrop
            spriteBatch.Draw(teardrop,
                new Vector2(835, 145),
                Color.White);

            spriteBatch.End();
        }

        public override void Update(GameTime gameTime, bool otherScreenHasFocus, bool coveredByOtherScreen)
        {
            base.Update(gameTime, otherScreenHasFocus, coveredByOtherScreen);
            position.Y--;
           
            if (position.Y < -textSize.Y)
                ScreenManager.RemoveScreen(this);
        }
        #endregion
    }
}

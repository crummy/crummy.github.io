﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PenguinPull
{
    /// <summary>
    /// Adds extra methods to Random
    /// </summary>
    class RandomPlus : Random
    {
        /// <summary>
        /// Returns a random number within a specified range.
        /// </summary>
        /// <param name="minValue">The inclusive lower bound of the number returned.</param>
        /// <param name="maxValue">The exclusive upper bound of the random number to be generated.</param>
        public double NextDouble(double minValue, double maxValue)
        {
            double range = maxValue - minValue;
            double sample = NextDouble();
            return ((sample * range) + minValue);
        }

        /// <summary>
        /// Returns a random number betweeen 0.0 and 1.0.
        /// </summary>
        public float NextFloat()
        {
            return (float)NextDouble();
        }

        /// <summary>
        /// Returns a random number within a specified range.
        /// </summary>
        /// <param name="minValue">The inclusive lower bound of the number returned.</param>
        /// <param name="maxValue">The exclusive upper bound of the random number to be generated.</param>
        public float NextFloat(float minValue, float maxValue)
        {
            return (float)NextDouble(minValue, maxValue);
        }

        /// <summary>
        /// Returns a random boolean (true or false)
        /// </summary>
        public bool NextBool()
        {
            return Next() % 2 == 1;
        }
    }
}

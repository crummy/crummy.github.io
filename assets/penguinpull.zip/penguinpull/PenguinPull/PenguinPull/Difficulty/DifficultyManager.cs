﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    /// <summary>
    /// Manages the difficulty of a particular unit by changing the frequency of its spawning.
    /// </summary>
    class DifficultyManager
    {
        #region Fields
        private IUnitList unitlist; //the unitlistgenerator which has its frequency modified.
        private CurveManager mincurve, maxcurve; //functions for setting the min and max frequencies of unitlist, respectively.
        private int updateFrequency, elapsedTime, totalTime; //how often unitlist is modified, time since last modification,
        //time since DifficultyManager instance was created (seconds)
        #endregion

        #region Methods
        /// <summary>
        /// DifficultyManager modifies the frequencies of a unitlist.
        /// </summary>
        /// <param name="unitlist">The unitlist to be modified.</param>
        /// <param name="mincurve">Function for the minimum frequency of unitlist.</param>
        /// <param name="maxcurve">Function for the maximum frequency of unitlist.</param>
        /// <param name="updateFrequency">How often (in milliseconds) the unitlist is modified when calling Update.</param>
        public DifficultyManager(IUnitList unitlist, CurveManager mincurve, CurveManager maxcurve, int updateFrequency = globals.MSecPerSec)
        {
            this.unitlist = unitlist;
            this.mincurve = mincurve;
            this.maxcurve = maxcurve;
            this.updateFrequency = updateFrequency;
            this.elapsedTime = 0;
        }

        /// <summary>
        /// If enough time has elapsed, modify the unitlist.
        /// </summary>
        /// <param name="gameTime">Provides timing for method in milliseconds and input for function in seconds.</param>
        public void Update(GameTime gameTime)
        {
            elapsedTime += gameTime.ElapsedGameTime.Milliseconds;

            if (elapsedTime >= updateFrequency)
            {
                totalTime += elapsedTime;
                unitlist.Frequency_Min = (int)mincurve.GetAt(totalTime / globals.MSecPerSec);
                unitlist.Frequency_Max = (int)maxcurve.GetAt(totalTime / globals.MSecPerSec);
                elapsedTime = 0;
            }
        }
        #endregion
    }
}

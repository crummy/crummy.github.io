﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PenguinPull
{
    /// <summary>
    /// Represents a scaled tanh function.
    /// </summary>
    class CurveManager
    {
        #region Fields
        /// <summary>
        /// multiplies the result of the hyperbolic tangent function.
        /// </summary>
        public double result_multiplier;

        /// <summary>
        /// the base which the input is added to before put into hyperbolic tangent function.
        /// </summary>
        public double input_base;

        /// <summary>
        /// multiplies the input before it is put into the hyperbolic tangent function.
        /// </summary>
        public double input_multiplier;

        /// <summary>
        /// the base value to which the curve is added.
        /// </summary>
        public double total_base;

        /// <summary>
        /// determines whether result is added or subtracted from total_base.
        /// </summary>
        public bool increment;
        #endregion

        #region Methods
        /// <summary>
        /// CurveManager creates a function based on hyperbolic tangent.
        /// The output of GetAt the function is:
        /// output = total_base (+ or -) result_multiplier * tanh(input_base + (input * input_multiplier))
        /// </summary>
        /// <param name="increment">If true, result of hyperbolic tangent is added to total_base.
        /// If false, result is subtracted from total_base.</param>
        public CurveManager(bool increment, double result_multiplier, double input_base, double input_multiplier, double total_base)
        {
            this.increment = increment;
            this.result_multiplier = result_multiplier;
            this.input_base = input_base;
            this.input_multiplier = input_multiplier;
            this.total_base = total_base;
        }

        /// <summary>
        /// Gets the output of the function at the specified input.
        /// output = total_base (+ or -) result_multiplier * tanh(input_base + (input * input_multiplier))
        /// </summary>
        public double GetAt(double input)
        {
            double tanhresult = result_multiplier * Math.Tanh(input_base + (input * input_multiplier));
            if (increment)
                return total_base + tanhresult;
            else
                return total_base - tanhresult;
        }
        #endregion
    }
}

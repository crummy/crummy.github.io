﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Xna.Framework;

namespace PenguinPull
{
    public partial class DebugInfo : Form
    {
        private InGame ingame;

        private int frequency;
        private int milliseconds;
        private int totalseconds;

        /// <summary>
        /// Creates a DebugInfo screen to provide various information about the game.
        /// </summary>
        /// <param name="ingame">The InGame game screen to provide information about.</param>
        internal DebugInfo(InGame ingame)
        {
            InitializeComponent();
            this.ingame = ingame;
            this.frequency = (int)UpdateFreqUpDown.Value * globals.MSecPerSec;
            this.milliseconds = 0;
            this.totalseconds = 0;
            UpdateTab();
        }

        #region Updates
        /// <summary>
        /// If enough time has elapsed, updates information.
        /// </summary>
        internal void Update(GameTime gameTime)
        {
            milliseconds += gameTime.ElapsedGameTime.Milliseconds;
            if (milliseconds > frequency)
            {
                totalseconds += (milliseconds / globals.MSecPerSec);
                milliseconds = 0;
                UpdateTab();
            }
        }

        /// <summary>
        /// Selects which tab to update and calls its update
        /// </summary>
        private void UpdateTab()
        {
            switch (InfoTabControl.SelectedIndex)
            {
                case 0:
                    UpdateGeneratorTab();
                    break;
                case 1:
                    UpdateUnitTab();
                    break;
            }
        }

        /// <summary>
        /// Updates the text information in the generator tab
        /// </summary>
        private void UpdateGeneratorTab()
        {
            GeneratorTextBox.Clear();

            GeneratorTextBox.Text += "Total Time: " + totalseconds + " seconds\r\n\r\n";

            GeneratorTextBox.Text += "cloudList min: " + ingame.cloudList.Frequency_Min + " milliseconds\r\n";
            GeneratorTextBox.Text += "cloudList max: " + ingame.cloudList.Frequency_Max + " milliseconds\r\n\r\n";

            GeneratorTextBox.Text += "icebergList min: " + ingame.icebergList.Frequency_Min + " milliseconds\r\n";
            GeneratorTextBox.Text += "icebergList max: " + ingame.icebergList.Frequency_Max + " milliseconds\r\n\r\n";

            GeneratorTextBox.Text += "penguinList min: " + ingame.penguinList.Frequency_Min + " milliseconds\r\n";
            GeneratorTextBox.Text += "penguinList max: " + ingame.penguinList.Frequency_Max + " milliseconds\r\n\r\n";

            GeneratorTextBox.Text += "rocketList min: " + ingame.rocketList.Frequency_Min + " milliseconds\r\n";
            GeneratorTextBox.Text += "rocketList max: " + ingame.rocketList.Frequency_Max + " milliseconds\r\n\r\n";

            GeneratorTextBox.Text += "whaleList min: " + ingame.whaleList.Frequency_Min + " milliseconds\r\n";
            GeneratorTextBox.Text += "whaleList max: " + ingame.whaleList.Frequency_Max + " milliseconds\r\n\r\n";
        }

        /// <summary>
        /// Updates the text information in the Unit tab
        /// </summary>
        private void UpdateUnitTab()
        {
            UnitTextBox.Clear();

            UnitTextBox.Text += "Total Time: " + totalseconds + " seconds\r\n\r\n";

            UnitTextBox.Text += "Alive Units\r\n";
            UnitTextBox.Text += "Clouds: " + CountLiveClouds() + "\r\n";
            UnitTextBox.Text += "Icebergs: " + CountLiveIcebergs() + "\r\n";
            UnitTextBox.Text += "Penguins: " + CountLivePenguins() + "\r\n";
            UnitTextBox.Text += "Rockets: " + CountLiveRockets() + "\r\n";
            UnitTextBox.Text += "Whales: " + CountLiveWhales() + "\r\n\r\n";

            UnitTextBox.Text += "Total Units\r\n";
            UnitTextBox.Text += "Clouds: " + ingame.cloudList.Count + "\r\n";
            UnitTextBox.Text += "Icebergs: " + ingame.icebergList.Count + "\r\n";
            UnitTextBox.Text += "Penguins: " + ingame.penguinList.Count + "\r\n";
            UnitTextBox.Text += "Rockets: " + ingame.rocketList.Count + "\r\n";
            UnitTextBox.Text += "Whales: " + ingame.whaleList.Count + "\r\n\r\n";
        }

        #region Counting
        /// <summary>
        /// Counts the number of clouds whose isAlive == true
        /// </summary>
        /// <returns>The number of clouds found alive</returns>
        private int CountLiveClouds()
        {
            int count = 0;
            foreach (Cloud cloud in ingame.cloudList)
            {
                if (cloud.isAlive)
                    ++count;
            }
            return count;
        }

        /// <summary>
        /// Counts the number of icebergs whose isAlive == true
        /// </summary>
        /// <returns>The number of icebergs found alive</returns>
        private int CountLiveIcebergs()
        {
            int count = 0;
            foreach (Iceberg iceberg in ingame.icebergList)
            {
                if (iceberg.isAlive)
                    ++count;
            }
            return count;
        }

        /// <summary>
        /// Counts the number of penguins whose isAlive == true
        /// </summary>
        /// <returns>The number of penguins found alive</returns>
        private int CountLivePenguins()
        {
            int count = 0;
            foreach (PenguinPowerup penguin in ingame.penguinList)
            {
                if (penguin.isAlive)
                    ++count;
            }
            return count;
        }

        /// <summary>
        /// Counts the number of rockets whose isAlive == true
        /// </summary>
        /// <returns>The number of rockets found alive</returns>
        private int CountLiveRockets()
        {
            int count = 0;
            foreach (RocketPowerup rocket in ingame.rocketList)
            {
                if (rocket.isAlive)
                    ++count;
            }
            return count;
        }

        /// <summary>
        /// Counts the number of whales whose isAlive == true
        /// </summary>
        /// <returns>The number of whales found alive</returns>
        private int CountLiveWhales()
        {
            int count = 0;
            foreach (Whale whale in ingame.whaleList)
            {
                if (whale.isAlive)
                    ++count;
            }
            return count;
        }
        #endregion

        #endregion

        #region Events
        /// <summary>
        /// If the numeric updown is modified, modify the frequency.
        /// </summary>
        private void UpdateFreqUpDown_ValueChanged(object sender, EventArgs e)
        {
            frequency = (int)UpdateFreqUpDown.Value * globals.MSecPerSec;
        }

        /// <summary>
        /// If the tab is changed, update the currently open tab.
        /// </summary>
        private void InfoTabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTab();
        }
        #endregion
    }
}

---
title: 'Prometheus: It&#8217;s a good thing I love sci fi'
author: Malcolm
layout: post
permalink: /prometheus-its-a-good-thing-i-love-sci-fi/87/
categories:
  - Uncategorized
---
I was pretty darned excited for Prometheus when I heard about it. Another Alien-ish movie from Ridley Scott? Sign me up. I always struggle a bit with movies like this: I want to know about it and see the trailer and get excited but I also want to avoid knowledge of the film so I can go in as free of expectations as possible. 

Anyway, I saw it in 3D last Friday (the 3D was actually pretty well done I thought) and feel pretty torn about the film. I love a good sci fi flick and immediately this was one of them: waking up from cryo sleep, holograms, robot guy, impractical but awesome sliding doors that every spaceship must have.

The film hinted a lot of cool ideas as well &#8211; the relationship between the creator and the created, both with respect to David the android as well as the engineers that apparently made humanity, especially with the initial scene between Weyland, his biological daughter, and his manufactured son. But while this was awkwardly explored I never felt satisfied, or that they&#8217;d discussed it any any kind of depth.

Overall my main issue was characters and their decisions. The unfortunate fact is that half a dozen untrained crew members in Alien were a thousand times more believable thanks to making significantly more sensible decisions and reactions, when compared to trained scientists(?) exploring an alien world like it&#8217;s their back yard, or the guy whose job it is to map the place getting lost.

Overall, there were definite parallels to Alien, and I think maybe the reason I was disappointed is that most of the things it did, Alien did better. I hope the film fares better after rewatching.
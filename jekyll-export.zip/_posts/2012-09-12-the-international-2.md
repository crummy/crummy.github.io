---
title: The International 2
author: Malcolm
layout: post
permalink: /the-international-2/118/
categories:
  - Uncategorized
---
An excellent thing happened at PAX this year: Valve&#8217;s second annual Dota 2 tournament, The International. Hosted just a few blocks away from my hotel, and with free entry for PAX attendees, it was easy to attend and I&#8217;m very glad I did. I&#8217;d seen the odd camera-pan-over-the-crowd from online broadcasts Starcraft 2 tournaments and thought to myself, boy, those people are serious nerds. However, it didn&#8217;t take long in the crowd before I was cheering at the top of my lungs with the crowd.

The location was amazing. Hosted at the Benaroya Hall in Seattle, there were balcony seats and fancy lighting and impressive entrances and even nice old ladies guiding people around &#8211; the kind of place you&#8217;d watch opera at, except for the two long cubicles on stage with five computers in them for each team. Matches were projected on a massive screen above the stage, with commentary from three separate tables, in English, Russian and Chinese.

Despite watching live streams of the odd Starcraft 2 or Dota 2 match, I&#8217;d always been a little dismissive of the e-sports scene (and I&#8217;m still a litty iffy about that label) but The International changed my point of view significantly. I&#8217;m not sure that I&#8217;d travel to Seattle just to see it again, but if it&#8217;s at the same time as PAX next year I&#8217;d sure like to catch a few games again.
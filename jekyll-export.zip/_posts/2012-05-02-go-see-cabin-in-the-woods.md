---
title: Go see The Cabin in the Woods
author: Malcolm
layout: post
permalink: /go-see-cabin-in-the-woods/72/
categories:
  - Uncategorized
---
<center>
  <a href="http://www.malcolmcrum.com/wp/wp-content/uploads/2012/05/cabin.jpg"><img class="aligncenter size-medium wp-image-73" title="Cabin in the Woods poster" src="http://www.malcolmcrum.com/wp/wp-content/uploads/2012/05/cabin-200x300.jpg" alt="" width="200" height="300" /></a>
</center>

I have two projects due this week and two midterms next week so all I&#8217;m going to say is: Go see [The Cabin in the Woods][1]. It&#8217;s a non-traditional horror movie, and I hardly like horror movies at all. That&#8217;s all the detail I want to get into because it&#8217;s really a movie you should go see with as few expectations as possible.

One thing I will say about it: It reminds me a bit of Community (a show I apparently should have been watching a long time ago) in that it&#8217;s story is told by context. My favourite Community episodes are the ones that are homages to particular genres or shows (the Law & Order one especially), and Cabin in the Woods draws on all other horror movies similarly: it&#8217;s a horror movie about horror movies.

If you&#8217;re anyone, you&#8217;ll love this movie, and if you like horror movies I&#8217;m sure you&#8217;ll enjoy it even more.

 [1]: http://www.imdb.com/title/tt1259521/
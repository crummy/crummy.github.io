---
title: Connect 4 in Python
author: Malcolm
layout: post
permalink: /connect-4-in-python/89/
categories:
  - Uncategorized
---
<center>
  <a href="http://www.malcolmcrum.com/wp/wp-content/uploads/2012/06/connect4.png"><img src="http://www.malcolmcrum.com/wp/wp-content/uploads/2012/06/connect4-300x236.png" alt="Screenshot of Connect 4" title="Connect 4" width="300" height="236" class="aligncenter size-medium wp-image-92" /></a>
</center>

I&#8217;m on a road trip from Santa Barbara to Portland, which should be the best time to write but the drive has given me writer&#8217;s cramp.

Instead, I made Connect 4 in Python, using Pygame, to refresh my Python knowledge. It only took a few hours, possibly thanks to Connect 4 being about the simplest game possible. It&#8217;s about 150 lines of code and half of that is my inefficient victory-checking code.

  * [Connect 4 source][1]

 [1]: http://www.malcolmcrum.com/wp/wp-content/uploads/2012/06/connect4.zip